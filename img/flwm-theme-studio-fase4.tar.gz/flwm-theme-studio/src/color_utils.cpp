// color_utils.cpp
#include "color_utils.h"

#include <cstdio>
#include <cstdlib>

namespace fts {

namespace {

bool isValidHex(const std::string& hex) {
    if (hex.size() != 7 || hex[0] != '#') return false;
    for (size_t i = 1; i < hex.size(); ++i) {
        char c = hex[i];
        bool isDigit = (c >= '0' && c <= '9');
        bool isLower = (c >= 'a' && c <= 'f');
        bool isUpper = (c >= 'A' && c <= 'F');
        if (!isDigit && !isLower && !isUpper) return false;
    }
    return true;
}

}  // namespace

void hexToRgb(const std::string& hex, unsigned char& r, unsigned char& g,
              unsigned char& b) {
    if (!isValidHex(hex)) {
        r = g = b = 0x80;  // gris neutro de reserva
        return;
    }
    unsigned int value = static_cast<unsigned int>(strtoul(hex.c_str() + 1, nullptr, 16));
    r = static_cast<unsigned char>((value >> 16) & 0xFF);
    g = static_cast<unsigned char>((value >> 8) & 0xFF);
    b = static_cast<unsigned char>(value & 0xFF);
}

std::string rgbToHex(unsigned char r, unsigned char g, unsigned char b) {
    char buf[8];
    snprintf(buf, sizeof(buf), "#%02x%02x%02x", r, g, b);
    return std::string(buf);
}

}  // namespace fts
