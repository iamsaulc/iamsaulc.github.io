// editor_window.h
// "Editor de tema": la ventana que se abre al pulsar "Editar" en la
// Biblioteca. Muestra las 5 categorías (General/Terminal/FLWM/Fuentes/
// Avanzado). Es dueña de la copia en memoria del tema que se está editando
// (workingTheme_) -- las ventanas de categoría escriben directamente sobre
// esa misma copia, así que "Guardar" desde cualquiera de ellas persiste
// TODOS los cambios hechos en cualquier categoría, no solo la actual.
//
// Navegación (ver diagrama acordado):
//   Biblioteca -> Editor de tema -> Ventana de categoría -> Guardar/Cancelar -> Biblioteca
//   con un atajo "Atrás" que vuelve de la categoría al menú sin guardar.

#ifndef FLWM_THEME_STUDIO_EDITOR_WINDOW_H
#define FLWM_THEME_STUDIO_EDITOR_WINDOW_H

#include <FL/Fl_Window.H>
#include <FL/Fl_Box.H>
#include <FL/Fl_Button.H>

#include <functional>
#include <string>

#include "theme.h"
#include "theme_library.h"

namespace fts {

class EditorWindow : public Fl_Window {
public:
    // themeFilePath: archivo .theme a editar (ya debe existir).
    // onClosed: se llama cuando el editor termina (Guardar o Cancelar) y
    // esta ventana ya se ocultó -- típicamente refresca la Biblioteca.
    EditorWindow(ThemeLibrary& library, const std::string& themeFilePath,
                 std::function<void()> onClosed);

    Theme& workingTheme() { return workingTheme_; }
    void markDirty();

    // Llamado por los botones "Atrás" de las ventanas de categoría: las
    // oculta y vuelve a mostrar este menú.
    void returnFromCategory();

    // Llamado por "Guardar"/"Cancelar" desde CUALQUIER ventana (el menú o
    // cualquier categoría). Cierran todo el flujo de edición.
    void saveAndClose();
    void cancelAndClose();

private:
    ThemeLibrary& library_;
    std::string filePath_;
    Theme workingTheme_;
    bool dirty_ = false;
    std::function<void()> onClosed_;

    Fl_Window* activeCategoryWindow_ = nullptr;
    Fl_Window* previewWindow_ = nullptr;

    Fl_Box* titleBox_;
    Fl_Box* dirtyBox_;

    static void onOpenGeneral(Fl_Widget*, void* userData);
    static void onOpenTerminal(Fl_Widget*, void* userData);
    static void onOpenFlwm(Fl_Widget*, void* userData);
    static void onOpenFonts(Fl_Widget*, void* userData);
    static void onOpenAdvanced(Fl_Widget*, void* userData);
    static void onOpenPreview(Fl_Widget*, void* userData);

    void closeAllWindows();
    void refreshTitle();
};

}  // namespace fts

#endif  // FLWM_THEME_STUDIO_EDITOR_WINDOW_H
