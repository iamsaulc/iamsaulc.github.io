// color_swatch_button.h
// Botón que se pinta a sí mismo con un color (formato "#rrggbb") y, al
// pulsarlo, abre el selector de color nativo de FLTK (Fl_Color_Chooser).
// Es la pieza que cumple el requisito de "el usuario nunca escribe hex a
// mano": todas las ventanas de categoría usan este widget para cada campo
// de color.

#ifndef FLWM_THEME_STUDIO_COLOR_SWATCH_BUTTON_H
#define FLWM_THEME_STUDIO_COLOR_SWATCH_BUTTON_H

#include <FL/Fl_Button.H>
#include <functional>
#include <string>

namespace fts {

class ColorSwatchButton : public Fl_Button {
public:
    ColorSwatchButton(int x, int y, int w, int h);

    void setHex(const std::string& hex);
    std::string hex() const { return hex_; }

    // Se invoca cada vez que el usuario elige un color nuevo desde el
    // selector (no en cada redibujado).
    void setOnChange(std::function<void()> cb) { onChange_ = cb; }

protected:
    void draw() override;

private:
    std::string hex_ = "#808080";
    std::function<void()> onChange_;

    static void handleClick(Fl_Widget*, void* userData);
    void openPicker();
};

}  // namespace fts

#endif  // FLWM_THEME_STUDIO_COLOR_SWATCH_BUTTON_H
