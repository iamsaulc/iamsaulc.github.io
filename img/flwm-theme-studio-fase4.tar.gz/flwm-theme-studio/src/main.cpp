// main.cpp
#include <FL/Fl.H>

#include "library_window.h"

int main(int argc, char** argv) {
    fts::LibraryWindow window;
    window.show(argc, argv);
    return Fl::run();
}
