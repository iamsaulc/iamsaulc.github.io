// library_window.h
// Ventana principal: SOLO administra la biblioteca de temas (buscar,
// aplicar, importar, exportar, duplicar, eliminar, nuevo). No contiene el
// editor -- ese es un flujo de ventanas independiente que se añadira en la
// fase 2, disparado desde el boton "Editar".

#ifndef FLWM_THEME_STUDIO_LIBRARY_WINDOW_H
#define FLWM_THEME_STUDIO_LIBRARY_WINDOW_H

#include <FL/Fl_Window.H>
#include <FL/Fl_Hold_Browser.H>
#include <FL/Fl_Input.H>
#include <FL/Fl_Button.H>
#include <FL/Fl_Box.H>
#include <FL/Fl_RGB_Image.H>

#include <vector>

#include "theme_library.h"

namespace fts {

class LibraryWindow : public Fl_Window {
public:
    LibraryWindow();
    ~LibraryWindow() override;
    void refreshList();

private:
    ThemeLibrary library_;
    std::vector<ThemeLibraryEntry> visibleEntries_;
    std::vector<Fl_RGB_Image*> thumbnails_;  // se regeneran en cada refreshList()

    Fl_Input* searchInput_;
    Fl_Hold_Browser* browser_;
    Fl_Box* statusBox_;

    Fl_Button* applyBtn_;
    Fl_Button* editBtn_;
    Fl_Button* newBtn_;
    Fl_Button* duplicateBtn_;
    Fl_Button* importBtn_;
    Fl_Button* exportBtn_;
    Fl_Button* deleteBtn_;
    Fl_Button* compareBtn_;

    int selectedIndex() const;  // índice en visibleEntries_, o -1

    static void onSearchChanged(Fl_Widget*, void* userData);
    static void onApply(Fl_Widget*, void* userData);
    static void onEdit(Fl_Widget*, void* userData);
    static void onNew(Fl_Widget*, void* userData);
    static void onDuplicate(Fl_Widget*, void* userData);
    static void onImport(Fl_Widget*, void* userData);
    static void onExport(Fl_Widget*, void* userData);
    static void onDelete(Fl_Widget*, void* userData);
    static void onCompare(Fl_Widget*, void* userData);

    void doApply();
    void doEdit();
    void doNew();
    void doDuplicate();
    void doImport();
    void doExport();
    void doDelete();
    void doCompare();

    void setStatus(const std::string& msg);
    void clearThumbnails();
};

}  // namespace fts

#endif  // FLWM_THEME_STUDIO_LIBRARY_WINDOW_H
