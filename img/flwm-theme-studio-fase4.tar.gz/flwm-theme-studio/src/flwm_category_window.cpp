// flwm_category_window.cpp
#include "flwm_category_window.h"

#include <FL/Fl_Box.H>

#include "category_nav.h"
#include "color_swatch_button.h"

namespace fts {

namespace {

struct FieldSpec {
    const char* label;
    const char* key;  // clave dentro de la sección "FLWM"
};

// Nota: flwm solo expone 4 recursos reales (background, foreground,
// activeBackground, activeForeground) -- no hay "texto activo/inactivo"
// como recursos separados de la barra. Los etiquetamos como pares
// activa/inactiva para que quede claro qué controla cada uno, en vez de
// inventar recursos X11 que flwm no soporta.
const FieldSpec kFields[] = {
    {"Barra inactiva - fondo", "background"},
    {"Barra inactiva - texto", "foreground"},
    {"Barra activa - fondo", "activeBackground"},
    {"Barra activa - texto", "activeForeground"},
};

}  // namespace

FlwmCategoryWindow::FlwmCategoryWindow(EditorWindow* editor)
    : Fl_Window(360, 260, "Editar tema - FLWM") {
    Theme& theme = editor->workingTheme();

    int margin = 16;
    int y = margin;
    int rowH = 40;
    int labelW = 170;
    int swatchW = 120;
    int swatchH = 28;

    for (const auto& field : kFields) {
        new Fl_Box(margin, y, labelW, swatchH, field.label);
        auto* swatch = new ColorSwatchButton(margin + labelW, y, swatchW, swatchH);
        swatch->setHex(theme.get("FLWM", field.key, "#808080"));

        std::string key = field.key;
        swatch->setOnChange([&theme, key, swatch, editor]() {
            theme.set("FLWM", key, swatch->hex());
            editor->markDirty();
        });

        y += rowH;
    }

    addCategoryNavButtons(this, w(), h(), editor,
                          [editor]() { editor->returnFromCategory(); });
    end();
}

}  // namespace fts
