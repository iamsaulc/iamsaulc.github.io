// theme_library.cpp
#include "theme_library.h"

#include <sys/stat.h>
#include <sys/types.h>
#include <dirent.h>
#include <unistd.h>

#include <algorithm>
#include <cstdlib>
#include <cctype>
#include <fstream>
#include <sstream>

#include "xdefaults.h"

namespace fts {

namespace {

bool dirExists(const std::string& path) {
    struct stat st;
    return stat(path.c_str(), &st) == 0 && S_ISDIR(st.st_mode);
}

bool fileExists(const std::string& path) {
    struct stat st;
    return stat(path.c_str(), &st) == 0 && S_ISREG(st.st_mode);
}

bool makeDir(const std::string& path) {
    if (dirExists(path)) return true;
    return mkdir(path.c_str(), 0755) == 0;
}

std::string readWholeFile(const std::string& path, bool& ok) {
    std::ifstream in(path.c_str());
    if (!in.is_open()) { ok = false; return ""; }
    std::ostringstream ss;
    ss << in.rdbuf();
    ok = true;
    return ss.str();
}

bool writeWholeFile(const std::string& path, const std::string& content) {
    std::ofstream out(path.c_str(), std::ios::trunc);
    if (!out.is_open()) return false;
    out << content;
    return true;
}

std::string homeDir() {
    const char* home = getenv("HOME");
    return home ? std::string(home) : std::string("/tmp");
}

}  // namespace

ThemeLibrary::ThemeLibrary() {
    configDir_ = homeDir() + "/.config/flwm-theme-studio";
    themesDir_ = configDir_ + "/themes";
    backupsDir_ = configDir_ + "/backups";
    currentFilePath_ = configDir_ + "/current";
}

bool ThemeLibrary::ensureDirectories(std::string& errorMessage) {
    if (!makeDir(homeDir() + "/.config")) {
        errorMessage = "No se pudo crear ~/.config";
        return false;
    }
    if (!makeDir(configDir_)) {
        errorMessage = "No se pudo crear " + configDir_;
        return false;
    }
    if (!makeDir(themesDir_)) {
        errorMessage = "No se pudo crear " + themesDir_;
        return false;
    }
    if (!makeDir(backupsDir_)) {
        errorMessage = "No se pudo crear " + backupsDir_;
        return false;
    }
    return true;
}

bool ThemeLibrary::ensureDefaultTheme(bool& outCreated, std::string& errorMessage) {
    outCreated = false;

    // Solo actuamos si la biblioteca esta realmente vacia. Si ya hay al
    // menos un tema, asumimos que esto ya se ejecuto antes (o que el
    // usuario ya gestiona sus propios temas) y no tocamos nada.
    if (!listThemes().empty()) return true;

    std::string xdefaultsPath = homeDir() + "/.Xdefaults";
    if (!fileExists(xdefaultsPath)) {
        // No hay nada que detectar; la biblioteca arranca vacia de verdad.
        return true;
    }

    std::string newPath;
    if (!importXdefaults(xdefaultsPath, "Predeterminado (detectado)", newPath,
                          errorMessage)) {
        return false;
    }

    // Este tema YA es, de hecho, el que esta aplicado en el sistema
    // (viene de leer el propio ~/.Xdefaults), asi que lo marcamos como
    // actual sin volver a escribir el archivo ni pedir confirmacion.
    if (!writeWholeFile(currentFilePath_, "Predeterminado (detectado)")) {
        errorMessage = "Tema creado pero no se pudo marcar como actual.";
        return false;
    }

    outCreated = true;
    return true;
}

std::string ThemeLibrary::slugify(const std::string& name) const {
    std::string slug;
    slug.reserve(name.size());
    for (char c : name) {
        if (std::isalnum(static_cast<unsigned char>(c))) {
            slug += c;
        } else if (c == ' ' || c == '-' || c == '_') {
            slug += '-';
        }
        // otros caracteres se descartan
    }
    if (slug.empty()) slug = "tema";
    return slug;
}

std::vector<ThemeLibraryEntry> ThemeLibrary::listThemes() const {
    std::vector<ThemeLibraryEntry> result;
    std::string current = currentThemeName();

    DIR* dir = opendir(themesDir_.c_str());
    if (!dir) return result;

    struct dirent* entry;
    while ((entry = readdir(dir)) != nullptr) {
        std::string fname = entry->d_name;
        if (fname.size() < 6) continue;
        if (fname.substr(fname.size() - 6) != ".theme") continue;

        std::string fullPath = themesDir_ + "/" + fname;
        Theme t;
        std::string err;
        if (loadTheme(fullPath, t, err)) {
            ThemeLibraryEntry e;
            e.name = t.name;
            e.filePath = fullPath;
            e.isCurrent = (t.name == current);
            result.push_back(e);
        }
    }
    closedir(dir);

    std::sort(result.begin(), result.end(),
              [](const ThemeLibraryEntry& a, const ThemeLibraryEntry& b) {
                  return a.name < b.name;
              });
    return result;
}

bool ThemeLibrary::loadTheme(const std::string& filePath, Theme& outTheme,
                              std::string& errorMessage) const {
    return loadThemeFile(filePath, outTheme, errorMessage);
}

bool ThemeLibrary::saveTheme(const Theme& theme, std::string& outFilePath,
                              std::string& errorMessage) const {
    outFilePath = themesDir_ + "/" + slugify(theme.name) + ".theme";
    return saveThemeFile(outFilePath, theme, errorMessage);
}

bool ThemeLibrary::deleteTheme(const std::string& filePath,
                                std::string& errorMessage) const {
    if (remove(filePath.c_str()) != 0) {
        errorMessage = "No se pudo eliminar: " + filePath;
        return false;
    }
    return true;
}

bool ThemeLibrary::duplicateTheme(const std::string& filePath,
                                   const std::string& newName,
                                   std::string& outNewFilePath,
                                   std::string& errorMessage) const {
    Theme original;
    if (!loadTheme(filePath, original, errorMessage)) return false;

    Theme copy = original;
    copy.name = newName.empty() ? (original.name + " copia") : newName;

    return saveTheme(copy, outNewFilePath, errorMessage);
}

bool ThemeLibrary::importXdefaults(const std::string& xdefaultsPath,
                                    const std::string& themeName,
                                    std::string& outFilePath,
                                    std::string& errorMessage) const {
    bool ok = false;
    std::string content = readWholeFile(xdefaultsPath, ok);
    if (!ok) {
        errorMessage = "No se pudo leer: " + xdefaultsPath;
        return false;
    }

    Theme theme = xdefaultsToTheme(content, themeName);
    return saveTheme(theme, outFilePath, errorMessage);
}

bool ThemeLibrary::exportXdefaults(const Theme& theme, const std::string& destPath,
                                    std::string& errorMessage) const {
    std::string content = themeToXdefaults(theme);
    if (!writeWholeFile(destPath, content)) {
        errorMessage = "No se pudo escribir: " + destPath;
        return false;
    }
    return true;
}

bool ThemeLibrary::applyTheme(const Theme& theme, bool createBackup,
                               std::string& errorMessage) const {
    std::string xdefaultsPath = homeDir() + "/.Xdefaults";

    if (createBackup && dirExists(backupsDir_)) {
        bool ok = false;
        std::string existing = readWholeFile(xdefaultsPath, ok);
        if (ok) {
            std::string backupPath = backupsDir_ + "/Xdefaults.bak";
            writeWholeFile(backupPath, existing);
        }
    }

    std::string content = themeToXdefaults(theme);
    if (!writeWholeFile(xdefaultsPath, content)) {
        errorMessage = "No se pudo escribir " + xdefaultsPath;
        return false;
    }

    // Decisión deliberada: NO se intenta fusionar en caliente (xrdb -merge)
    // ni reiniciar flwm aquí. Mezclar una recarga parcial con un aviso de
    // "reinicia tu equipo" dejaría al usuario en un estado intermedio
    // confuso (algunos colores cambiados, otros no). Simplificamos: el
    // archivo queda escrito y lo comunicamos claramente, y es la ventana
    // que llama a applyTheme() la que le pide al usuario reiniciar.
    writeWholeFile(currentFilePath_, theme.name);
    return true;
}

std::string ThemeLibrary::currentThemeName() const {
    bool ok = false;
    std::string content = readWholeFile(currentFilePath_, ok);
    if (!ok) return "";
    // quitar posible salto de linea final
    while (!content.empty() && (content.back() == '\n' || content.back() == '\r')) {
        content.pop_back();
    }
    return content;
}

}  // namespace fts
