// thumbnail.cpp
#include "thumbnail.h"

#include "color_utils.h"

namespace fts {

Fl_RGB_Image* makeThemeThumbnail(const Theme& theme, int size) {
    unsigned char bgR, bgG, bgB;
    unsigned char accR, accG, accB;

    hexToRgb(theme.get("General", "background", "#808080"), bgR, bgG, bgB);
    // Preferimos el acento de la barra activa de FLWM (el color mas
    // "de marca" de un tema); si el tema no tiene FLWM definido, caemos
    // al color de seleccion general.
    std::string accent = theme.hasKey("FLWM", "activeBackground")
                              ? theme.get("FLWM", "activeBackground")
                              : theme.get("General", "selectColor", "#808080");
    hexToRgb(accent, accR, accG, accB);

    const int depth = 3;  // RGB
    unsigned char* pixels = new unsigned char[size * size * depth];

    for (int row = 0; row < size; ++row) {
        for (int col = 0; col < size; ++col) {
            // Diagonal simple: triangulo superior-izquierdo = fondo,
            // triangulo inferior-derecho = acento.
            bool upperLeft = (col + row) < size;
            unsigned char r = upperLeft ? bgR : accR;
            unsigned char g = upperLeft ? bgG : accG;
            unsigned char b = upperLeft ? bgB : accB;

            int idx = (row * size + col) * depth;
            pixels[idx + 0] = r;
            pixels[idx + 1] = g;
            pixels[idx + 2] = b;
        }
    }

    auto* image = new Fl_RGB_Image(pixels, size, size, depth);
    image->alloc_array = 1;  // la imagen se encarga de liberar 'pixels'
    return image;
}

}  // namespace fts
