// compare_window.h
// Comparador de temas: el usuario elige dos temas de la biblioteca y ve
// unicamente las diferencias, campo por campo, tal como pide la
// especificacion ("Background: Rojo -> Azul", etc). Ventana de solo
// lectura -- no edita nada, solo ayuda a decidir que copiar a mano si se
// quiere crear una variante.

#ifndef FLWM_THEME_STUDIO_COMPARE_WINDOW_H
#define FLWM_THEME_STUDIO_COMPARE_WINDOW_H

#include <FL/Fl_Window.H>
#include <FL/Fl_Choice.H>
#include <FL/Fl_Browser.H>

#include <vector>

#include "theme_library.h"

namespace fts {

class CompareWindow : public Fl_Window {
public:
    explicit CompareWindow(const std::vector<ThemeLibraryEntry>& entries);

private:
    std::vector<ThemeLibraryEntry> entries_;
    ThemeLibrary library_;

    Fl_Choice* choiceA_;
    Fl_Choice* choiceB_;
    Fl_Browser* diffBrowser_;

    void refreshDiff();
    static void onChoiceChanged(Fl_Widget*, void* userData);
};

}  // namespace fts

#endif  // FLWM_THEME_STUDIO_COMPARE_WINDOW_H
