// preview_window.cpp
#include "preview_window.h"

#include <FL/Fl.H>
#include <FL/fl_draw.H>

#include "color_utils.h"

namespace fts {

namespace {

Fl_Color hexToFlColor(const std::string& hex) {
    unsigned char r, g, b;
    hexToRgb(hex, r, g, b);
    return fl_rgb_color(r, g, b);
}

}  // namespace

PreviewWindow::PreviewWindow(EditorWindow* editor)
    : Fl_Window(260, 220, "Vista previa"), editor_(editor) {
    // No confiamos en que el gestor de ventanas la coloque sin solaparse
    // con el editor (algunos WM ligeros, como el propio flwm, no
    // reposicionan ventanas nuevas de forma inteligente): la situamos a
    // la derecha del editor de forma explicita.
    int px = editor->x() + editor->w() + 20;
    int py = editor->y();
    position(px, py);

    titleBar_ = new Fl_Box(0, 0, w(), 24, "Ventana de ejemplo");
    titleBar_->box(FL_FLAT_BOX);
    titleBar_->align(FL_ALIGN_CENTER);
    titleBar_->labelfont(FL_HELVETICA_BOLD);

    int margin = 12;
    int y = 24 + margin;

    sampleButton_ = new Fl_Button(margin, y, w() - 2 * margin, 26, "Boton de ejemplo");
    y += 26 + 8;

    sampleInput_ = new Fl_Input(margin, y, w() - 2 * margin, 24, "");
    sampleInput_->value("Entrada de texto");
    y += 24 + 8;

    sampleList_ = new Fl_Hold_Browser(margin, y, w() - 2 * margin, 70);
    sampleList_->add("Elemento 1");
    sampleList_->add("Elemento 2");
    sampleList_->add("Elemento 3");
    sampleList_->value(1);
    y += 70 + 8;

    sampleLabel_ = new Fl_Box(margin, y, w() - 2 * margin, 22, "Etiqueta de ejemplo");
    sampleLabel_->align(FL_ALIGN_LEFT | FL_ALIGN_INSIDE);

    end();

    refreshFromTheme();
    show();

    Fl::add_timeout(0.3, tick, this);
}

PreviewWindow::~PreviewWindow() {
    Fl::remove_timeout(tick, this);
}

void PreviewWindow::tick(void* userData) {
    auto* self = static_cast<PreviewWindow*>(userData);
    self->refreshFromTheme();
    Fl::repeat_timeout(0.3, tick, userData);
}

void PreviewWindow::refreshFromTheme() {
    Theme& theme = editor_->workingTheme();

    Fl_Color bg = hexToFlColor(theme.get("General", "background", "#808080"));
    Fl_Color fg = hexToFlColor(theme.get("General", "foreground", "#000000"));
    Fl_Color bg2 = hexToFlColor(theme.get("General", "background2", "#808080"));
    Fl_Color select = hexToFlColor(theme.get("General", "selectColor", "#808080"));
    Fl_Color flwmBg = hexToFlColor(theme.get("FLWM", "activeBackground", "#808080"));
    Fl_Color flwmFg = hexToFlColor(theme.get("FLWM", "activeForeground", "#ffffff"));
    Fl_Color labelColor = hexToFlColor(theme.get("General", "labelcolor", "#000000"));

    color(bg);

    titleBar_->color(flwmBg);
    titleBar_->labelcolor(flwmFg);

    sampleButton_->color(bg2);
    sampleButton_->labelcolor(fg);

    sampleInput_->color(bg2);
    sampleInput_->textcolor(fg);

    sampleList_->color(bg2);
    sampleList_->textcolor(fg);
    sampleList_->selection_color(select);

    sampleLabel_->labelcolor(labelColor);

    redraw();
}

}  // namespace fts
