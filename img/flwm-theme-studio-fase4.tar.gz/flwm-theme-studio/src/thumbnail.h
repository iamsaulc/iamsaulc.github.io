// thumbnail.h
// Genera una miniatura pequeña y barata para cada tema de la Biblioteca:
// un recuadro partido en diagonal con el fondo general y el acento de
// FLWM, sin necesidad de recrear FLWM real ni de tocar disco (todo se
// calcula en memoria a partir del propio Theme).

#ifndef FLWM_THEME_STUDIO_THUMBNAIL_H
#define FLWM_THEME_STUDIO_THUMBNAIL_H

#include <FL/Fl_RGB_Image.H>

#include "theme.h"

namespace fts {

// El puntero devuelto es propiedad de quien llama (usar delete cuando ya
// no se necesite). El buffer de pixeles vive dentro de la propia imagen
// (alloc_array activado), así que un solo delete basta.
Fl_RGB_Image* makeThemeThumbnail(const Theme& theme, int size = 28);

}  // namespace fts

#endif  // FLWM_THEME_STUDIO_THUMBNAIL_H
