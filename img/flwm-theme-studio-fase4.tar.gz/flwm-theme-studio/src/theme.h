// theme.h
// Modelo de datos central: un Theme es simplemente un conjunto de secciones,
// cada una con pares clave=valor. Esto cubre General/Terminal/ANSI/FLWM/
// Fonts/Advanced sin necesitar una clase distinta por sección: la UI de cada
// ventana de categoría simplemente lee/escribe en la sección que le
// corresponde, y "Advanced" recibe cualquier clave X11 que no reconozcamos.
//
// C++11, sin dependencias externas. Compatible con arquitecturas de 32 bits.

#ifndef FLWM_THEME_STUDIO_THEME_H
#define FLWM_THEME_STUDIO_THEME_H

#include <map>
#include <string>
#include <vector>

namespace fts {

// Orden canónico de secciones. Se usa para escribir los .theme siempre en
// el mismo orden, y por la UI para saber qué pestañas mostrar.
extern const std::vector<std::string> kSectionOrder;

// Un Theme completo.
class Theme {
public:
    // Metadatos (van en la sección especial [Meta])
    std::string name;
    std::string description;
    int version = 1;

    // sectionName -> (key -> value). Las claves dentro de cada sección son
    // las que definimos nosotros (ver theme_schema.h) salvo en "Advanced",
    // donde la clave es el recurso X11 original tal cual (p. ej.
    // "*Text_Display*labelcolor").
    std::map<std::string, std::map<std::string, std::string> > sections;

    // Acceso cómodo con valor por defecto si la clave no existe.
    std::string get(const std::string& section, const std::string& key,
                     const std::string& defaultValue = "") const;

    void set(const std::string& section, const std::string& key,
             const std::string& value);

    bool hasKey(const std::string& section, const std::string& key) const;

    // Devuelve una copia profunda (map ya hace copia por valor, esto es
    // solo por claridad de intención en el código que llama a "Duplicar").
    Theme clone() const { return *this; }
};

// Carga/guarda el formato interno .theme (tipo INI). Devuelve false y deja
// errorMessage si algo falla (archivo no encontrado, formato corrupto, etc.)
bool loadThemeFile(const std::string& path, Theme& outTheme,
                    std::string& errorMessage);

bool saveThemeFile(const std::string& path, const Theme& theme,
                    std::string& errorMessage);

}  // namespace fts

#endif  // FLWM_THEME_STUDIO_THEME_H
