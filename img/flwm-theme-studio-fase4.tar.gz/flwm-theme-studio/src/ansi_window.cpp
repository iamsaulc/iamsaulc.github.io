// ansi_window.cpp
#include "ansi_window.h"

#include <FL/Fl_Box.H>

#include <string>

#include "category_nav.h"
#include "color_swatch_button.h"

namespace fts {

namespace {

void addRow(Theme& theme, EditorWindow* editor, int startIndex, int y) {
    int swatchW = 70, swatchH = 60, gap = 8, margin = 16;
    for (int i = 0; i < 8; ++i) {
        int colorIndex = startIndex + i;
        int x = margin + i * (swatchW + gap);
        std::string key = "color" + std::to_string(colorIndex);

        Fl_Box* indexBox = new Fl_Box(x, y, swatchW, 16);
        indexBox->copy_label(std::to_string(colorIndex).c_str());
        auto* swatch = new ColorSwatchButton(x, y + 16, swatchW, swatchH);
        swatch->setHex(theme.get("ANSI", key, "#808080"));
        swatch->setOnChange([&theme, key, swatch, editor]() {
            theme.set("ANSI", key, swatch->hex());
            editor->markDirty();
        });
    }
}

}  // namespace

AnsiWindow::AnsiWindow(EditorWindow* editor, std::function<void()> onBack)
    : Fl_Window(660, 230, "Editar tema - Colores ANSI") {
    Theme& theme = editor->workingTheme();

    new Fl_Box(16, 8, 300, 20, "Colores 0-7 (basicos)");
    addRow(theme, editor, 0, 34);

    new Fl_Box(16, 108, 300, 20, "Colores 8-15 (intensos / bold)");
    addRow(theme, editor, 8, 134);

    addCategoryNavButtons(this, w(), h(), editor, std::move(onBack));
    end();
}

}  // namespace fts
