// theme_diff.cpp
#include "theme_diff.h"

#include <algorithm>
#include <set>

namespace fts {

std::vector<DiffEntry> computeThemeDiff(const Theme& a, const Theme& b) {
    std::vector<DiffEntry> result;

    // Unión de todas las secciones presentes en cualquiera de los dos temas.
    std::set<std::string> allSections;
    for (const auto& kv : a.sections) allSections.insert(kv.first);
    for (const auto& kv : b.sections) allSections.insert(kv.first);

    for (const auto& section : allSections) {
        std::set<std::string> allKeys;
        auto itA = a.sections.find(section);
        auto itB = b.sections.find(section);
        if (itA != a.sections.end()) {
            for (const auto& kv : itA->second) allKeys.insert(kv.first);
        }
        if (itB != b.sections.end()) {
            for (const auto& kv : itB->second) allKeys.insert(kv.first);
        }

        for (const auto& key : allKeys) {
            std::string valueA = a.get(section, key, "");
            std::string valueB = b.get(section, key, "");
            if (valueA != valueB) {
                result.push_back(DiffEntry{section, key, valueA, valueB});
            }
        }
    }

    std::sort(result.begin(), result.end(), [](const DiffEntry& x, const DiffEntry& y) {
        if (x.section != y.section) return x.section < y.section;
        return x.key < y.key;
    });

    return result;
}

}  // namespace fts
