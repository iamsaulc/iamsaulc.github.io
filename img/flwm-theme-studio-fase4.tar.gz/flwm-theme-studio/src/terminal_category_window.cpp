// terminal_category_window.cpp
#include "terminal_category_window.h"

#include <FL/Fl_Box.H>
#include <FL/Fl_Button.H>
#include <FL/Fl_Check_Button.H>
#include <FL/Fl_Int_Input.H>

#include <string>

#include "ansi_window.h"
#include "category_nav.h"
#include "color_swatch_button.h"

namespace fts {

namespace {

// Pequeño helper de enlace para campos de texto/número: cada input queda
// atado a una sección+clave del Theme y marca el editor como "sucio" al
// cambiar. Se reutiliza para title/font/shading/saveLines.
struct InputBinding {
    Theme* theme;
    std::string section;
    std::string key;
    EditorWindow* editor;
    Fl_Input* input;
};

void onInputChanged(Fl_Widget*, void* userData) {
    auto* b = static_cast<InputBinding*>(userData);
    b->theme->set(b->section, b->key, b->input->value());
    b->editor->markDirty();
}

Fl_Input* addTextField(int x, int y, int w, int h, Theme& theme,
                        const std::string& section, const std::string& key,
                        const std::string& defaultValue, EditorWindow* editor,
                        bool numeric) {
    Fl_Input* input = numeric ? new Fl_Int_Input(x, y, w, h)
                               : new Fl_Input(x, y, w, h);
    input->value(theme.get(section, key, defaultValue).c_str());

    // Vive mientras viva la ventana; misma simplificación de gestión de
    // memoria que category_nav.cpp (ver comentario alli).
    auto* binding = new InputBinding{&theme, section, key, editor, input};
    input->callback(onInputChanged, binding);
    input->when(FL_WHEN_CHANGED);
    return input;
}

struct CheckBinding {
    Theme* theme;
    std::string section;
    std::string key;
    EditorWindow* editor;
    Fl_Check_Button* check;
};

void onCheckChanged(Fl_Widget*, void* userData) {
    auto* b = static_cast<CheckBinding*>(userData);
    b->theme->set(b->section, b->key, b->check->value() ? "true" : "false");
    b->editor->markDirty();
}

Fl_Check_Button* addCheckbox(int x, int y, int w, int h, const char* label,
                              Theme& theme, const std::string& section,
                              const std::string& key, bool defaultValue,
                              EditorWindow* editor) {
    Fl_Check_Button* check = new Fl_Check_Button(x, y, w, h, label);
    std::string current = theme.get(section, key, defaultValue ? "true" : "false");
    check->value(current == "true" ? 1 : 0);

    auto* binding = new CheckBinding{&theme, section, key, editor, check};
    check->callback(onCheckChanged, binding);
    return check;
}

}  // namespace

TerminalCategoryWindow::TerminalCategoryWindow(EditorWindow* editor)
    : Fl_Window(420, 420, "Editar tema - Terminal"), editor_(editor) {
    Theme& theme = editor->workingTheme();

    int margin = 16;
    int y = margin;
    int labelW = 140;
    int swatchW = 120;
    int swatchH = 28;
    int rowH = 38;

    new Fl_Box(margin, y, labelW, swatchH, "Fondo");
    auto* bg = new ColorSwatchButton(margin + labelW, y, swatchW, swatchH);
    bg->setHex(theme.get("Terminal", "background", "#000000"));
    bg->setOnChange([&theme, bg, editor]() {
        theme.set("Terminal", "background", bg->hex());
        editor->markDirty();
    });
    y += rowH;

    new Fl_Box(margin, y, labelW, swatchH, "Texto");
    auto* fg = new ColorSwatchButton(margin + labelW, y, swatchW, swatchH);
    fg->setHex(theme.get("Terminal", "foreground", "#ffffff"));
    fg->setOnChange([&theme, fg, editor]() {
        theme.set("Terminal", "foreground", fg->hex());
        editor->markDirty();
    });
    y += rowH;

    new Fl_Box(margin, y, labelW, swatchH, "Cursor");
    auto* cursor = new ColorSwatchButton(margin + labelW, y, swatchW, swatchH);
    cursor->setHex(theme.get("Terminal", "cursorColor", "#ffffff"));
    cursor->setOnChange([&theme, cursor, editor]() {
        theme.set("Terminal", "cursorColor", cursor->hex());
        editor->markDirty();
    });
    y += rowH + 6;

    addCheckbox(margin, y, 200, 24, "Transparencia", theme, "Terminal",
                "transparent", false, editor);
    y += 30;

    addCheckbox(margin, y, 200, 24, "Mostrar scrollbar", theme, "Terminal",
                "scrollBar", false, editor);
    y += 34;

    new Fl_Box(margin, y, labelW, 24, "Nivel de sombreado (0-100)");
    addTextField(margin + labelW, y, 80, 24, theme, "Terminal", "shading",
                 "80", editor, /*numeric=*/true);
    y += 32;

    new Fl_Box(margin, y, labelW, 24, "Titulo de la ventana");
    addTextField(margin + labelW, y, 180, 24, theme, "Terminal", "title",
                 "Terminal", editor, /*numeric=*/false);
    y += 32;

    new Fl_Box(margin, y, labelW, 24, "Fuente (X11)");
    addTextField(margin + labelW, y, 180, 24, theme, "Terminal", "font",
                 "fixed", editor, /*numeric=*/false);
    y += 32;

    new Fl_Box(margin, y, labelW, 24, "Lineas de historial");
    addTextField(margin + labelW, y, 80, 24, theme, "Terminal", "saveLines",
                 "2000", editor, /*numeric=*/true);
    y += 40;

    Fl_Button* ansiBtn = new Fl_Button(margin, y, 260, 30, "Editar colores ANSI...");
    ansiBtn->callback(onOpenAnsi, this);

    addCategoryNavButtons(this, w(), h(), editor,
                          [editor]() { editor->returnFromCategory(); });
    end();
}

void TerminalCategoryWindow::onOpenAnsi(Fl_Widget*, void* userData) {
    auto* self = static_cast<TerminalCategoryWindow*>(userData);
    self->hide();
    auto* ansi = new AnsiWindow(self->editor_, [self]() {
        self->show();
    });
    ansi->show();
}

}  // namespace fts
