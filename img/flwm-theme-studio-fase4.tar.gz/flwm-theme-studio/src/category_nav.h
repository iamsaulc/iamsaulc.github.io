// category_nav.h
// Fila de botones "← Atrás / Guardar / Cancelar" que reaparece en TODAS
// las ventanas de categoría, tal como pide la especificación. Se centraliza
// aquí para no repetir el mismo bloque de código en General/Terminal/FLWM.
//
// "Guardar" y "Cancelar" son siempre globales: pase lo que pase, guardan o
// descartan TODO el tema y cierran el flujo de edición completo. "Atrás"
// es contextual -- normalmente vuelve al menú de categorías, pero por
// ejemplo la ventana ANSI necesita volver a Terminal en vez de al menú,
// así que se recibe como una función a medida en cada ventana.

#ifndef FLWM_THEME_STUDIO_CATEGORY_NAV_H
#define FLWM_THEME_STUDIO_CATEGORY_NAV_H

#include <functional>

class Fl_Group;

namespace fts {

class EditorWindow;

// Añade los tres botones en la parte inferior de `parent`, asumiendo que
// la ventana mide winW x winH. Debe llamarse ANTES de parent->end().
// "Guardar"/"Cancelar" siempre actúan sobre `editor`; "onBack" define a
// dónde vuelve el botón "← Atrás" de ESTA ventana en concreto.
void addCategoryNavButtons(Fl_Group* parent, int winW, int winH,
                            EditorWindow* editor, std::function<void()> onBack);

}  // namespace fts

#endif  // FLWM_THEME_STUDIO_CATEGORY_NAV_H
