// general_category_window.h
// Ventana de categoría "General": fondo, texto, etiquetas, selección y
// background2. Cada campo es un ColorSwatchButton -- el usuario nunca
// escribe un código hexadecimal a mano.

#ifndef FLWM_THEME_STUDIO_GENERAL_CATEGORY_WINDOW_H
#define FLWM_THEME_STUDIO_GENERAL_CATEGORY_WINDOW_H

#include <FL/Fl_Window.H>

#include "editor_window.h"

namespace fts {

class GeneralCategoryWindow : public Fl_Window {
public:
    explicit GeneralCategoryWindow(EditorWindow* editor);
};

}  // namespace fts

#endif  // FLWM_THEME_STUDIO_GENERAL_CATEGORY_WINDOW_H
