// theme_library.h
// Gestiona la biblioteca de temas en disco:
//   ~/.config/flwm-theme-studio/themes/*.theme
//   ~/.config/flwm-theme-studio/current      (nombre del tema activo)
//   ~/.config/flwm-theme-studio/backups/     (copias de ~/.Xdefaults)
//
// Usa solo llamadas POSIX (dirent.h, sys/stat.h) en vez de <filesystem>
// para mantener compatibilidad con compiladores GCC antiguos en 32 bits.

#ifndef FLWM_THEME_STUDIO_THEME_LIBRARY_H
#define FLWM_THEME_STUDIO_THEME_LIBRARY_H

#include <string>
#include <vector>

#include "theme.h"

namespace fts {

struct ThemeLibraryEntry {
    std::string name;       // Theme.name
    std::string filePath;   // ruta completa al .theme
    bool isCurrent = false;
};

class ThemeLibrary {
public:
    ThemeLibrary();

    // Crea ~/.config/flwm-theme-studio/{themes,backups} si no existen.
    bool ensureDirectories(std::string& errorMessage);

    // Primer uso: si la biblioteca esta vacia y existe un ~/.Xdefaults
    // real del usuario, lo importa como tema "Predeterminado (detectado)"
    // y lo marca como tema actual -- porque de hecho ya es el que esta
    // aplicado en el sistema. No hace nada si ya hay temas en la
    // biblioteca (para no duplicar en ejecuciones posteriores) ni si no
    // existe ~/.Xdefaults (nada que detectar).
    // Devuelve true siempre que no haya un error real de E/S; outCreated
    // indica si efectivamente se creo el tema por defecto.
    bool ensureDefaultTheme(bool& outCreated, std::string& errorMessage);

    // Lista los temas disponibles, marcando cuál es el actualmente aplicado.
    std::vector<ThemeLibraryEntry> listThemes() const;

    bool loadTheme(const std::string& filePath, Theme& outTheme,
                   std::string& errorMessage) const;

    // Guarda un tema. Si el theme.name cambia el nombre de archivo se
    // deriva de nuevo (slug), por lo que devuelve la ruta final usada.
    bool saveTheme(const Theme& theme, std::string& outFilePath,
                   std::string& errorMessage) const;

    bool deleteTheme(const std::string& filePath, std::string& errorMessage) const;

    // Duplicar: copia el tema con un nuevo nombre (por defecto "<nombre> copia").
    bool duplicateTheme(const std::string& filePath, const std::string& newName,
                         std::string& outNewFilePath, std::string& errorMessage) const;

    // Importa un .Xdefaults externo y lo guarda como nuevo tema en la biblioteca.
    bool importXdefaults(const std::string& xdefaultsPath, const std::string& themeName,
                          std::string& outFilePath, std::string& errorMessage) const;

    // Exporta un tema como archivo .Xdefaults independiente (sin tocar el
    // ~/.Xdefaults real del usuario).
    bool exportXdefaults(const Theme& theme, const std::string& destPath,
                         std::string& errorMessage) const;

    // Aplica un tema: genera ~/.Xdefaults, hace backup del anterior si
    // procede, corre `xrdb -merge` y marca el tema como actual. NO reinicia
    // flwm todavía -- eso se decide en una fase posterior (ver conversación).
    bool applyTheme(const Theme& theme, bool createBackup,
                     std::string& errorMessage) const;

    std::string currentThemeName() const;

    std::string themesDir() const { return themesDir_; }
    std::string configDir() const { return configDir_; }

private:
    std::string configDir_;
    std::string themesDir_;
    std::string backupsDir_;
    std::string currentFilePath_;

    std::string slugify(const std::string& name) const;
};

}  // namespace fts

#endif  // FLWM_THEME_STUDIO_THEME_LIBRARY_H
