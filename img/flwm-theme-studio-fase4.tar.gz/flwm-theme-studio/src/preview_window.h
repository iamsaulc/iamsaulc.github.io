// preview_window.h
// Vista previa en vivo: una ventana pequeña con controles FLTK reales
// (barra de titulo simulada, boton, entrada de texto, lista, etiqueta)
// coloreados con el tema que se esta editando. No reemplaza al menu del
// editor ni a las ventanas de categoria -- coexiste con ellas a proposito,
// para que los cambios de color se vean de inmediato mientras se editan
// en otra ventana.

#ifndef FLWM_THEME_STUDIO_PREVIEW_WINDOW_H
#define FLWM_THEME_STUDIO_PREVIEW_WINDOW_H

#include <FL/Fl_Window.H>
#include <FL/Fl_Box.H>
#include <FL/Fl_Button.H>
#include <FL/Fl_Input.H>
#include <FL/Fl_Hold_Browser.H>

#include "editor_window.h"

namespace fts {

class PreviewWindow : public Fl_Window {
public:
    explicit PreviewWindow(EditorWindow* editor);
    ~PreviewWindow() override;

    // Vuelve a leer los colores del tema en edicion y repinta. Se llama
    // periodicamente mientras la ventana esta abierta.
    void refreshFromTheme();

private:
    EditorWindow* editor_;

    Fl_Box* titleBar_;
    Fl_Button* sampleButton_;
    Fl_Input* sampleInput_;
    Fl_Hold_Browser* sampleList_;
    Fl_Box* sampleLabel_;

    static void tick(void* userData);
};

}  // namespace fts

#endif  // FLWM_THEME_STUDIO_PREVIEW_WINDOW_H
