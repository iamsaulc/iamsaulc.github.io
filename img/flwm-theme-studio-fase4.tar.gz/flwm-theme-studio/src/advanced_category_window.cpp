// advanced_category_window.cpp
#include "advanced_category_window.h"

#include <FL/Fl_Box.H>

#include <sstream>

#include "category_nav.h"

namespace fts {

namespace {

std::string trim(const std::string& s) {
    size_t start = s.find_first_not_of(" \t\r\n");
    if (start == std::string::npos) return "";
    size_t end = s.find_last_not_of(" \t\r\n");
    return s.substr(start, end - start + 1);
}

// Reconstruye el texto mostrado a partir de la sección "Advanced" actual,
// ordenado alfabeticamente para que sea facil de escanear visualmente.
std::string sectionToText(const Theme& theme) {
    std::ostringstream out;
    auto it = theme.sections.find("Advanced");
    if (it != theme.sections.end()) {
        for (const auto& kv : it->second) {
            out << kv.first << "=" << kv.second << "\n";
        }
    }
    return out.str();
}

// Convierte el texto editado de vuelta a un mapa clave=valor. Lineas sin
// '=' , vacias o que empiecen por '#'/';' se ignoran silenciosamente --
// preferimos tolerar texto a medio escribir a bloquear al usuario con un
// error mientras teclea.
void textToSection(const std::string& text, std::map<std::string, std::string>& out) {
    out.clear();
    std::istringstream in(text);
    std::string line;
    while (std::getline(in, line)) {
        std::string trimmed = trim(line);
        if (trimmed.empty() || trimmed[0] == '#' || trimmed[0] == ';') continue;
        size_t eq = trimmed.find('=');
        if (eq == std::string::npos) continue;
        std::string key = trim(trimmed.substr(0, eq));
        std::string value = trim(trimmed.substr(eq + 1));
        if (key.empty()) continue;
        out[key] = value;
    }
}

struct ModifyContext {
    EditorWindow* editor;
    Fl_Text_Buffer* buffer;
};

void onTextModified(int, int nInserted, int nDeleted, int, const char*, void* userData) {
    if (nInserted == 0 && nDeleted == 0) return;  // llamada inicial sin cambio real
    auto* ctx = static_cast<ModifyContext*>(userData);
    char* text = ctx->buffer->text();
    std::map<std::string, std::string> parsed;
    textToSection(std::string(text), parsed);
    free(text);

    ctx->editor->workingTheme().sections["Advanced"] = parsed;
    ctx->editor->markDirty();
}

}  // namespace

AdvancedCategoryWindow::AdvancedCategoryWindow(EditorWindow* editor)
    : Fl_Window(460, 420, "Editar tema - Avanzado") {
    int margin = 12;

    Fl_Box* help = new Fl_Box(margin, margin, w() - 2 * margin, 40,
        "Una linea por recurso: clave=valor\n"
        "(recursos X11 que no encajan en otra categoria)");
    help->align(FL_ALIGN_LEFT | FL_ALIGN_INSIDE | FL_ALIGN_WRAP);
    help->labelsize(11);
    help->labelcolor(FL_DARK3);

    int editorY = margin + 46;
    int editorH = h() - editorY - 30 - 2 * margin;

    buffer_ = new Fl_Text_Buffer();
    buffer_->text(sectionToText(editor->workingTheme()).c_str());

    auto* editorWidget = new Fl_Text_Editor(margin, editorY, w() - 2 * margin, editorH);
    editorWidget->buffer(buffer_);
    editorWidget->textfont(FL_COURIER);
    editorWidget->textsize(12);

    // Igual que el resto de callbacks de categoria: se aloja en el heap y
    // vive lo que vive la ventana.
    auto* ctx = new ModifyContext{editor, buffer_};
    buffer_->add_modify_callback(onTextModified, ctx);

    addCategoryNavButtons(this, w(), h(), editor,
                          [editor]() { editor->returnFromCategory(); });
    end();
}

}  // namespace fts
