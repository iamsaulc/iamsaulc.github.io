// library_window.cpp
#include "library_window.h"

#include <FL/Fl.H>
#include <FL/fl_ask.H>
#include <FL/Fl_File_Chooser.H>

#include "editor_window.h"
#include "thumbnail.h"
#include "compare_window.h"

#include <algorithm>
#include <cctype>

namespace fts {

namespace {

std::string toLower(const std::string& s) {
    std::string r = s;
    std::transform(r.begin(), r.end(), r.begin(),
                    [](unsigned char c) { return std::tolower(c); });
    return r;
}

}  // namespace

LibraryWindow::LibraryWindow()
    : Fl_Window(520, 420, "FLWM Theme Studio - Biblioteca") {
    std::string err;
    library_.ensureDirectories(err);

    bool defaultCreated = false;
    std::string defaultErr;
    library_.ensureDefaultTheme(defaultCreated, defaultErr);

    int margin = 12;
    int y = margin;

    searchInput_ = new Fl_Input(margin + 70, y, w() - 2 * margin - 70, 26, "Buscar:");
    searchInput_->callback(onSearchChanged, this);
    searchInput_->when(FL_WHEN_CHANGED);
    y += 34;

    browser_ = new Fl_Hold_Browser(margin, y, w() - 2 * margin, 230);
    y += 230 + 10;

    statusBox_ = new Fl_Box(margin, y, w() - 2 * margin, 22);
    statusBox_->align(FL_ALIGN_LEFT | FL_ALIGN_INSIDE);
    y += 28;

    int btnW = (w() - 2 * margin - 6 * 6) / 7;
    int x = margin;
    int btnH = 30;

    applyBtn_ = new Fl_Button(x, y, btnW, btnH, "Aplicar");
    applyBtn_->callback(onApply, this);
    x += btnW + 6;

    editBtn_ = new Fl_Button(x, y, btnW, btnH, "Editar");
    editBtn_->callback(onEdit, this);
    x += btnW + 6;

    newBtn_ = new Fl_Button(x, y, btnW, btnH, "Nuevo");
    newBtn_->callback(onNew, this);
    x += btnW + 6;

    duplicateBtn_ = new Fl_Button(x, y, btnW, btnH, "Duplicar");
    duplicateBtn_->callback(onDuplicate, this);
    x += btnW + 6;

    importBtn_ = new Fl_Button(x, y, btnW, btnH, "Importar");
    importBtn_->callback(onImport, this);
    x += btnW + 6;

    exportBtn_ = new Fl_Button(x, y, btnW, btnH, "Exportar");
    exportBtn_->callback(onExport, this);
    x += btnW + 6;

    deleteBtn_ = new Fl_Button(x, y, btnW, btnH, "Eliminar");
    deleteBtn_->callback(onDelete, this);
    y += btnH + 10;

    int compareW = 160;
    compareBtn_ = new Fl_Button((w() - compareW) / 2, y, compareW, btnH, "Comparar dos temas...");
    compareBtn_->callback(onCompare, this);

    end();

    if (!err.empty()) setStatus(err);
    refreshList();

    if (defaultCreated) {
        fl_message("Se detecto tu ~/.Xdefaults actual y se guardo en la\n"
                    "biblioteca como 'Predeterminado (detectado)', marcado\n"
                    "como tema actual. Asi no pierdes tu configuracion de\n"
                    "partida al empezar a usar la aplicacion.");
    } else if (!defaultErr.empty()) {
        setStatus(defaultErr);
    }
}

void LibraryWindow::clearThumbnails() {
    for (auto* img : thumbnails_) delete img;
    thumbnails_.clear();
}

LibraryWindow::~LibraryWindow() {
    clearThumbnails();
}

void LibraryWindow::refreshList() {
    std::string filter = toLower(searchInput_->value());
    visibleEntries_.clear();
    browser_->clear();
    clearThumbnails();

    std::vector<ThemeLibraryEntry> all = library_.listThemes();
    std::string currentName = library_.currentThemeName();

    for (const auto& e : all) {
        if (!filter.empty() && toLower(e.name).find(filter) == std::string::npos) {
            continue;
        }
        visibleEntries_.push_back(e);
        std::string label = e.name;
        if (e.isCurrent) label += "  [aplicado]";
        browser_->add(label.c_str());

        Theme t;
        std::string loadErr;
        if (library_.loadTheme(e.filePath, t, loadErr)) {
            Fl_RGB_Image* thumb = makeThemeThumbnail(t, 20);
            thumbnails_.push_back(thumb);
            browser_->icon(browser_->size(), thumb);
        }
    }

    if (all.empty()) {
        setStatus("La biblioteca esta vacia. Usa Importar o Nuevo para empezar.");
    } else {
        setStatus("Tema actual: " +
                   (currentName.empty() ? std::string("(ninguno aplicado aun)") : currentName));
    }
}

int LibraryWindow::selectedIndex() const {
    int line = browser_->value();  // 1-based, 0 si nada seleccionado
    if (line <= 0) return -1;
    int idx = line - 1;
    if (idx < 0 || idx >= static_cast<int>(visibleEntries_.size())) return -1;
    return idx;
}

void LibraryWindow::setStatus(const std::string& msg) {
    statusBox_->copy_label(msg.c_str());
    statusBox_->redraw();
}

// ---- callbacks estáticos -> despachan a métodos de instancia ----

void LibraryWindow::onSearchChanged(Fl_Widget*, void* userData) {
    static_cast<LibraryWindow*>(userData)->refreshList();
}
void LibraryWindow::onApply(Fl_Widget*, void* userData) {
    static_cast<LibraryWindow*>(userData)->doApply();
}
void LibraryWindow::onEdit(Fl_Widget*, void* userData) {
    static_cast<LibraryWindow*>(userData)->doEdit();
}
void LibraryWindow::onNew(Fl_Widget*, void* userData) {
    static_cast<LibraryWindow*>(userData)->doNew();
}
void LibraryWindow::onDuplicate(Fl_Widget*, void* userData) {
    static_cast<LibraryWindow*>(userData)->doDuplicate();
}
void LibraryWindow::onCompare(Fl_Widget*, void* userData) {
    static_cast<LibraryWindow*>(userData)->doCompare();
}
void LibraryWindow::onImport(Fl_Widget*, void* userData) {
    static_cast<LibraryWindow*>(userData)->doImport();
}
void LibraryWindow::onExport(Fl_Widget*, void* userData) {
    static_cast<LibraryWindow*>(userData)->doExport();
}
void LibraryWindow::onDelete(Fl_Widget*, void* userData) {
    static_cast<LibraryWindow*>(userData)->doDelete();
}

// ---- acciones ----

void LibraryWindow::doApply() {
    int idx = selectedIndex();
    if (idx < 0) { fl_alert("Selecciona primero un tema de la lista."); return; }

    Theme theme;
    std::string err;
    if (!library_.loadTheme(visibleEntries_[idx].filePath, theme, err)) {
        fl_alert("No se pudo cargar el tema:\n%s", err.c_str());
        return;
    }

    if (!fl_choice("¿Aplicar '%s' ahora?\n"
                    "Se sobrescribira tu ~/.Xdefaults actual y necesitaras\n"
                    "reiniciar el equipo para ver los cambios completos.",
                    "Cancelar", "Aplicar", nullptr, theme.name.c_str())) {
        return;
    }

    if (!library_.applyTheme(theme, /*createBackup=*/true, err)) {
        fl_alert("No se pudo aplicar el tema:\n%s", err.c_str());
        return;
    }

    setStatus("Tema '" + theme.name + "' aplicado. Reinicia el equipo para verlo.");
    refreshList();

    fl_message("Tema '%s' aplicado.\n\n"
               "Reinicia tu equipo para que los cambios se vean\n"
               "completos en la terminal y en flwm.",
               theme.name.c_str());
}

void LibraryWindow::doEdit() {
    int idx = selectedIndex();
    if (idx < 0) { fl_alert("Selecciona primero un tema de la lista."); return; }

    std::string themeFilePath = visibleEntries_[idx].filePath;
    // El editor toma la ventana de Biblioteca en pausa mientras se edita:
    // al cerrarse (Guardar o Cancelar) refrescamos la lista para reflejar
    // cualquier cambio de nombre o valores.
    hide();
    auto* editor = new EditorWindow(library_, themeFilePath, [this]() {
        refreshList();
        show();
    });
    editor->show();
}

void LibraryWindow::doNew() {
    const char* name = fl_input("Nombre del nuevo tema:", "Mi tema");
    if (!name || std::string(name).empty()) return;

    Theme theme;
    theme.name = name;
    theme.description = "";
    // Valores por defecto minimos y razonables para que el tema sea
    // aplicable de inmediato aunque el usuario aun no haya tocado nada.
    theme.set("General", "background", "#2e2e2e");
    theme.set("General", "foreground", "#e0e0e0");
    theme.set("General", "labelcolor", "#e0e0e0");
    theme.set("General", "selectColor", "#5e81ac");
    theme.set("General", "background2", "#1e1e1e");
    theme.set("Terminal", "background", "#2e2e2e");
    theme.set("Terminal", "foreground", "#e0e0e0");
    theme.set("Terminal", "cursorColor", "#5e81ac");
    theme.set("FLWM", "background", "#2e2e2e");
    theme.set("FLWM", "foreground", "#e0e0e0");
    theme.set("FLWM", "activeBackground", "#5e81ac");
    theme.set("FLWM", "activeForeground", "#ffffff");
    theme.set("Fonts", "family", "helvetica-12");

    std::string path, err;
    if (!library_.saveTheme(theme, path, err)) {
        fl_alert("No se pudo crear el tema:\n%s", err.c_str());
        return;
    }
    refreshList();
}

void LibraryWindow::doDuplicate() {
    int idx = selectedIndex();
    if (idx < 0) { fl_alert("Selecciona primero un tema de la lista."); return; }

    std::string suggested = visibleEntries_[idx].name + " copia";
    const char* name = fl_input("Nombre para la copia:", suggested.c_str());
    if (!name) return;

    std::string newPath, err;
    if (!library_.duplicateTheme(visibleEntries_[idx].filePath, name, newPath, err)) {
        fl_alert("No se pudo duplicar:\n%s", err.c_str());
        return;
    }
    refreshList();
}

void LibraryWindow::doImport() {
    Fl_File_Chooser chooser(getenv("HOME") ? getenv("HOME") : "/",
                             "*", Fl_File_Chooser::SINGLE,
                             "Importar .Xdefaults");
    chooser.show();
    while (chooser.shown()) Fl::wait();
    if (!chooser.value()) return;

    std::string path = chooser.value();
    std::string suggested = "Tema importado";
    const char* name = fl_input("Nombre para el tema importado:", suggested.c_str());
    if (!name) return;

    std::string newPath, err;
    if (!library_.importXdefaults(path, name, newPath, err)) {
        fl_alert("No se pudo importar:\n%s", err.c_str());
        return;
    }
    refreshList();
}

void LibraryWindow::doExport() {
    int idx = selectedIndex();
    if (idx < 0) { fl_alert("Selecciona primero un tema de la lista."); return; }

    Theme theme;
    std::string err;
    if (!library_.loadTheme(visibleEntries_[idx].filePath, theme, err)) {
        fl_alert("No se pudo cargar el tema:\n%s", err.c_str());
        return;
    }

    Fl_File_Chooser chooser(getenv("HOME") ? getenv("HOME") : "/",
                             "*", Fl_File_Chooser::CREATE,
                             "Exportar como .Xdefaults");
    chooser.show();
    while (chooser.shown()) Fl::wait();
    if (!chooser.value()) return;

    if (!library_.exportXdefaults(theme, chooser.value(), err)) {
        fl_alert("No se pudo exportar:\n%s", err.c_str());
        return;
    }
    setStatus("Tema exportado a " + std::string(chooser.value()));
}

void LibraryWindow::doDelete() {
    int idx = selectedIndex();
    if (idx < 0) { fl_alert("Selecciona primero un tema de la lista."); return; }

    if (!fl_choice("¿Eliminar '%s' definitivamente?",
                    "Cancelar", "Eliminar", nullptr,
                    visibleEntries_[idx].name.c_str())) {
        return;
    }

    std::string err;
    if (!library_.deleteTheme(visibleEntries_[idx].filePath, err)) {
        fl_alert("No se pudo eliminar:\n%s", err.c_str());
        return;
    }
    refreshList();
}

void LibraryWindow::doCompare() {
    if (visibleEntries_.size() < 2) {
        fl_alert("Necesitas al menos dos temas en la biblioteca para comparar.");
        return;
    }
    new CompareWindow(visibleEntries_);
}

}  // namespace fts
