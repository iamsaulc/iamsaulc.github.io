// ansi_window.h
// Ventana independiente para los 16 colores ANSI (0-7 primero, luego
// 8-15), tal como pide la especificación. Cuelga de Terminal, no del
// menú de categorías: su "Atrás" vuelve a Terminal, no al Editor de tema.

#ifndef FLWM_THEME_STUDIO_ANSI_WINDOW_H
#define FLWM_THEME_STUDIO_ANSI_WINDOW_H

#include <FL/Fl_Window.H>

#include <functional>

#include "editor_window.h"

namespace fts {

class AnsiWindow : public Fl_Window {
public:
    AnsiWindow(EditorWindow* editor, std::function<void()> onBack);
};

}  // namespace fts

#endif  // FLWM_THEME_STUDIO_ANSI_WINDOW_H
