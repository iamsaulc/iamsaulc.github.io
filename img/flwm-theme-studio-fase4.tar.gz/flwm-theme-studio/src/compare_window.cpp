// compare_window.cpp
#include "compare_window.h"

#include <FL/Fl_Box.H>
#include <FL/Fl_Button.H>
#include <FL/fl_ask.H>

#include "theme.h"
#include "theme_diff.h"

namespace fts {

namespace {

// Nombres legibles para mostrar en el listado de diferencias, en vez de
// las claves internas crudas.
std::string sectionLabel(const std::string& section) {
    if (section == "General") return "General";
    if (section == "Terminal") return "Terminal";
    if (section == "ANSI") return "ANSI";
    if (section == "FLWM") return "FLWM";
    if (section == "Fonts") return "Fuentes";
    if (section == "Advanced") return "Avanzado";
    return section;
}

}  // namespace

CompareWindow::CompareWindow(const std::vector<ThemeLibraryEntry>& entries)
    : Fl_Window(560, 420, "Comparar temas"), entries_(entries) {
    int margin = 12;
    int y = margin;

    int labelW = 60;
    int choiceW = (w() - 2 * margin - labelW * 2 - 10) / 2;

    new Fl_Box(margin, y, labelW, 26, "Tema A:");
    choiceA_ = new Fl_Choice(margin + labelW, y, choiceW, 26);

    new Fl_Box(margin + labelW + choiceW + 10, y, labelW, 26, "Tema B:");
    choiceB_ = new Fl_Choice(margin + labelW + choiceW + 10 + labelW, y, choiceW, 26);

    for (const auto& e : entries_) {
        choiceA_->add(e.name.c_str());
        choiceB_->add(e.name.c_str());
    }
    choiceA_->value(0);
    choiceB_->value(entries_.size() > 1 ? 1 : 0);

    choiceA_->callback(onChoiceChanged, this);
    choiceB_->callback(onChoiceChanged, this);

    y += 36;

    diffBrowser_ = new Fl_Browser(margin, y, w() - 2 * margin, h() - y - margin - 40);
    // Fl_Browser guarda el puntero, no copia el array: debe vivir tanto
    // como la ventana. Se filtra deliberadamente (misma politica que el
    // resto de callbacks de categoria en esta app).
    diffBrowser_->column_widths((new int[4]{210, 150, 150, 0}));
    diffBrowser_->column_char('\t');

    Fl_Button* closeBtn = new Fl_Button(margin, h() - margin - 30, 100, 30, "Cerrar");
    closeBtn->callback([](Fl_Widget* w, void*) { w->window()->hide(); });

    end();
    refreshDiff();
    show();
}

void CompareWindow::onChoiceChanged(Fl_Widget*, void* userData) {
    static_cast<CompareWindow*>(userData)->refreshDiff();
}

void CompareWindow::refreshDiff() {
    diffBrowser_->clear();

    int idxA = choiceA_->value();
    int idxB = choiceB_->value();
    if (idxA < 0 || idxB < 0 || idxA >= static_cast<int>(entries_.size()) ||
        idxB >= static_cast<int>(entries_.size())) {
        return;
    }

    diffBrowser_->add("@b\tCampo\tA\tB");

    if (idxA == idxB) {
        diffBrowser_->add("Selecciona dos temas distintos para ver diferencias.");
        return;
    }

    Theme themeA, themeB;
    std::string err;
    if (!library_.loadTheme(entries_[idxA].filePath, themeA, err) ||
        !library_.loadTheme(entries_[idxB].filePath, themeB, err)) {
        diffBrowser_->add("No se pudo cargar uno de los dos temas.");
        return;
    }

    std::vector<DiffEntry> diffs = computeThemeDiff(themeA, themeB);
    if (diffs.empty()) {
        diffBrowser_->add("Estos dos temas son identicos en todos los campos conocidos.");
        return;
    }

    for (const auto& d : diffs) {
        if (d.section == "Meta") continue;  // nombre/descripcion no son "campos de color"
        std::string valA = d.valueA.empty() ? "(sin definir)" : d.valueA;
        std::string valB = d.valueB.empty() ? "(sin definir)" : d.valueB;
        std::string line = sectionLabel(d.section) + " - " + d.key + "\t" + valA + "\t" + valB;
        diffBrowser_->add(line.c_str());
    }
}

}  // namespace fts
