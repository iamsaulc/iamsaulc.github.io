// color_utils.h
// Conversion entre "#rrggbb" y componentes r,g,b (0-255). Se centraliza
// aqui porque ya la necesitan tres piezas distintas: los recuadros de
// color, las miniaturas de la Biblioteca y la vista previa.

#ifndef FLWM_THEME_STUDIO_COLOR_UTILS_H
#define FLWM_THEME_STUDIO_COLOR_UTILS_H

#include <string>

namespace fts {

// Si hex no tiene formato "#rrggbb" valido, devuelve un gris neutro
// (#808080) en vez de fallar -- preferimos un color de reserva visible a
// bloquear por un tema mal formado.
void hexToRgb(const std::string& hex, unsigned char& r, unsigned char& g,
              unsigned char& b);

std::string rgbToHex(unsigned char r, unsigned char g, unsigned char b);

}  // namespace fts

#endif  // FLWM_THEME_STUDIO_COLOR_UTILS_H
