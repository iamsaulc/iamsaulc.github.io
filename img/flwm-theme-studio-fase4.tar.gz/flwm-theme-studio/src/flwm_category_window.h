// flwm_category_window.h
// Ventana de categoría "FLWM": fondo, texto, barra activa, barra inactiva
// (fondo/texto), tal como pide la especificación -- nada más.

#ifndef FLWM_THEME_STUDIO_FLWM_CATEGORY_WINDOW_H
#define FLWM_THEME_STUDIO_FLWM_CATEGORY_WINDOW_H

#include <FL/Fl_Window.H>

#include "editor_window.h"

namespace fts {

class FlwmCategoryWindow : public Fl_Window {
public:
    explicit FlwmCategoryWindow(EditorWindow* editor);
};

}  // namespace fts

#endif  // FLWM_THEME_STUDIO_FLWM_CATEGORY_WINDOW_H
