// color_swatch_button.cpp
#include "color_swatch_button.h"

#include <FL/Fl_Color_Chooser.H>
#include <FL/fl_draw.H>

#include "color_utils.h"

namespace fts {

ColorSwatchButton::ColorSwatchButton(int x, int y, int w, int h)
    : Fl_Button(x, y, w, h, "") {
    box(FL_UP_BOX);
    callback(handleClick, this);
}

void ColorSwatchButton::setHex(const std::string& hex) {
    hex_ = hex;
    redraw();
}

void ColorSwatchButton::draw() {
    uchar r, g, b;
    hexToRgb(hex_, r, g, b);

    fl_color(fl_rgb_color(r, g, b));
    fl_rectf(x(), y(), w(), h());
    fl_color(FL_BLACK);
    fl_rect(x(), y(), w(), h());

    // Texto legible: negro sobre colores claros, blanco sobre oscuros.
    int luminance = (r * 299 + g * 587 + b * 114) / 1000;
    fl_color(luminance > 140 ? FL_BLACK : FL_WHITE);
    fl_font(FL_HELVETICA, 11);
    fl_draw(hex_.c_str(), x(), y(), w(), h(), FL_ALIGN_CENTER);
}

void ColorSwatchButton::handleClick(Fl_Widget*, void* userData) {
    static_cast<ColorSwatchButton*>(userData)->openPicker();
}

void ColorSwatchButton::openPicker() {
    uchar r, g, b;
    hexToRgb(hex_, r, g, b);
    double dr = r / 255.0, dg = g / 255.0, db = b / 255.0;

    if (fl_color_chooser("Elegir color", dr, dg, db)) {
        uchar nr = static_cast<uchar>(dr * 255.0 + 0.5);
        uchar ng = static_cast<uchar>(dg * 255.0 + 0.5);
        uchar nb = static_cast<uchar>(db * 255.0 + 0.5);
        hex_ = rgbToHex(nr, ng, nb);
        redraw();
        if (onChange_) onChange_();
    }
}

}  // namespace fts
