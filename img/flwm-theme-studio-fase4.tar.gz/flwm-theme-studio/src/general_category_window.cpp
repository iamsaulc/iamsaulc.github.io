// general_category_window.cpp
#include "general_category_window.h"

#include <FL/Fl_Box.H>

#include "category_nav.h"
#include "color_swatch_button.h"

namespace fts {

namespace {

struct FieldSpec {
    const char* label;
    const char* key;  // clave dentro de la sección "General"
};

const FieldSpec kFields[] = {
    {"Fondo", "background"},
    {"Texto", "foreground"},
    {"Etiquetas", "labelcolor"},
    {"Seleccion", "selectColor"},
    {"Fondo 2 (paneles)", "background2"},
};

}  // namespace

GeneralCategoryWindow::GeneralCategoryWindow(EditorWindow* editor)
    : Fl_Window(360, 300, "Editar tema - General") {
    Theme& theme = editor->workingTheme();

    int margin = 16;
    int y = margin;
    int rowH = 40;
    int labelW = 150;
    int swatchW = 120;
    int swatchH = 28;

    for (const auto& field : kFields) {
        new Fl_Box(margin, y, labelW, swatchH, field.label);
        auto* swatch = new ColorSwatchButton(margin + labelW, y, swatchW, swatchH);
        swatch->setHex(theme.get("General", field.key, "#808080"));

        // Captura por valor de lo necesario; swatch y theme viven mientras
        // viva esta ventana / el editor, así que las referencias son
        // seguras durante todo el ciclo de vida relevante.
        std::string key = field.key;
        swatch->setOnChange([&theme, key, swatch, editor]() {
            theme.set("General", key, swatch->hex());
            editor->markDirty();
        });

        y += rowH;
    }

    addCategoryNavButtons(this, w(), h(), editor,
                          [editor]() { editor->returnFromCategory(); });
    end();
}

}  // namespace fts
