// fonts_category_window.cpp
#include "fonts_category_window.h"

#include <FL/Fl_Box.H>
#include <FL/Fl_Choice.H>
#include <FL/Fl_Spinner.H>
#include <FL/Fl_Check_Button.H>

#include <cctype>
#include <cstdio>
#include <cstdlib>
#include <functional>
#include <string>

#include "category_nav.h"

namespace fts {

namespace {

// Nombres de familia habituales en instalaciones FLTK/X11 clasicas. Si el
// valor guardado no esta en esta lista, se añade igualmente como primera
// opcion para no perder la configuracion original del usuario.
const char* kKnownFamilies[] = {
    "helvetica", "helvetica-bold", "helvetica-italic", "helvetica-bold-italic",
    "courier", "courier-bold", "times", "times-bold", "screen", "fixed",
};

// Separa "helvetica-12" en familia="helvetica" y tamaño=12. Si no hay un
// sufijo numerico tras el ultimo guion, se asume tamaño 12 por defecto y
// toda la cadena se trata como familia.
void splitFamilySize(const std::string& value, std::string& family, int& size) {
    family = value.empty() ? "helvetica" : value;
    size = 12;

    size_t lastDash = value.find_last_of('-');
    if (lastDash == std::string::npos || lastDash + 1 >= value.size()) return;

    std::string suffix = value.substr(lastDash + 1);
    for (char c : suffix) {
        if (!std::isdigit(static_cast<unsigned char>(c))) return;  // no es numerico
    }

    family = value.substr(0, lastDash);
    size = std::atoi(suffix.c_str());
}

std::string joinFamilySize(const std::string& family, int size) {
    return family + "-" + std::to_string(size);
}

}  // namespace

FontsCategoryWindow::FontsCategoryWindow(EditorWindow* editor)
    : Fl_Window(360, 300, "Editar tema - Fuentes") {
    Theme& theme = editor->workingTheme();

    int margin = 16;
    int y = margin;
    int labelW = 110;
    int fieldW = 360 - 2 * margin - labelW;
    int rowH = 40;

    std::string family;
    int size = 12;
    splitFamilySize(theme.get("Fonts", "family", "helvetica-12"), family, size);

    new Fl_Box(margin, y, labelW, 26, "Familia");
    auto* familyChoice = new Fl_Choice(margin + labelW, y, fieldW, 26);
    int selectedIndex = -1;
    bool found = false;
    for (const char* known : kKnownFamilies) {
        int idx = familyChoice->add(known);
        if (family == known) { selectedIndex = idx; found = true; }
    }
    if (!found) {
        selectedIndex = familyChoice->add(family.c_str());
    }
    familyChoice->value(selectedIndex);
    y += rowH;

    new Fl_Box(margin, y, labelW, 26, "Tamaño");
    auto* sizeSpinner = new Fl_Spinner(margin + labelW, y, fieldW, 26);
    sizeSpinner->type(FL_INT_INPUT);
    sizeSpinner->range(6, 72);
    sizeSpinner->step(1);
    sizeSpinner->value(size);
    y += rowH;

    // Familia y tamaño se guardan combinados en Fonts.family, asi que
    // cualquier cambio en uno de los dos controles reescribe el valor
    // combinado completo.
    auto commitFamily = [&theme, editor, familyChoice, sizeSpinner]() {
        std::string fam = familyChoice->text() ? familyChoice->text() : "helvetica";
        int sz = static_cast<int>(sizeSpinner->value());
        theme.set("Fonts", "family", joinFamilySize(fam, sz));
        editor->markDirty();
    };
    // Fl_Widget::callback solo admite un puntero void*, asi que guardamos
    // las lambdas en el heap; viven mientras viva esta ventana (se filtran
    // deliberadamente, igual que el resto de callbacks de categoria: el
    // coste es insignificante frente a la vida de la ventana).
    auto* familyCb = new std::function<void()>(commitFamily);
    familyChoice->callback([](Fl_Widget*, void* v) {
        (*static_cast<std::function<void()>*>(v))();
    }, familyCb);

    auto* sizeCb = new std::function<void()>(commitFamily);
    sizeSpinner->callback([](Fl_Widget*, void* v) {
        (*static_cast<std::function<void()>*>(v))();
    }, sizeCb);

    new Fl_Box(margin, y, labelW, 26, "DPI");
    auto* dpiSpinner = new Fl_Spinner(margin + labelW, y, fieldW, 26);
    dpiSpinner->type(FL_FLOAT_INPUT);
    dpiSpinner->range(60, 200);
    dpiSpinner->step(1);
    std::string dpiStr = theme.get("Fonts", "dpi", "96.0");
    dpiSpinner->value(std::atof(dpiStr.c_str()));
    auto* dpiCb = new std::function<void()>([&theme, editor, dpiSpinner]() {
        char buf[32];
        snprintf(buf, sizeof(buf), "%.1f", dpiSpinner->value());
        theme.set("Fonts", "dpi", buf);
        editor->markDirty();
    });
    dpiSpinner->callback([](Fl_Widget*, void* v) {
        (*static_cast<std::function<void()>*>(v))();
    }, dpiCb);
    y += rowH;

    auto* antialiasCheck = new Fl_Check_Button(margin + labelW, y, fieldW, 26, "Antialias");
    antialiasCheck->value(theme.get("Fonts", "antialias", "1") == "1");
    auto* antialiasCb = new std::function<void()>([&theme, editor, antialiasCheck]() {
        theme.set("Fonts", "antialias", antialiasCheck->value() ? "1" : "0");
        editor->markDirty();
    });
    antialiasCheck->callback([](Fl_Widget*, void* v) {
        (*static_cast<std::function<void()>*>(v))();
    }, antialiasCb);
    y += 32;

    auto* hintingCheck = new Fl_Check_Button(margin + labelW, y, fieldW, 26, "Hinting");
    hintingCheck->value(theme.get("Fonts", "hinting", "1") == "1");
    auto* hintingCb = new std::function<void()>([&theme, editor, hintingCheck]() {
        theme.set("Fonts", "hinting", hintingCheck->value() ? "1" : "0");
        editor->markDirty();
    });
    hintingCheck->callback([](Fl_Widget*, void* v) {
        (*static_cast<std::function<void()>*>(v))();
    }, hintingCb);

    addCategoryNavButtons(this, w(), h(), editor,
                          [editor]() { editor->returnFromCategory(); });
    end();
}

}  // namespace fts
