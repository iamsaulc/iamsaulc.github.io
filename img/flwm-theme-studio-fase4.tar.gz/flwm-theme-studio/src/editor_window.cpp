// editor_window.cpp
#include "editor_window.h"

#include <FL/Fl.H>
#include <FL/fl_ask.H>

#include "flwm_category_window.h"
#include "fonts_category_window.h"
#include "general_category_window.h"
#include "terminal_category_window.h"
#include "advanced_category_window.h"
#include "preview_window.h"
#include "category_nav.h"

namespace fts {

EditorWindow::EditorWindow(ThemeLibrary& library, const std::string& themeFilePath,
                            std::function<void()> onClosed)
    : Fl_Window(360, 450, "Editor de tema"),
      library_(library),
      filePath_(themeFilePath),
      onClosed_(std::move(onClosed)) {
    std::string err;
    if (!library_.loadTheme(themeFilePath, workingTheme_, err)) {
        // Avisamos de inmediato: mejor que el usuario sepa que algo fue
        // mal a que edite "a ciegas" un tema que en realidad no se cargó.
        fl_alert("No se pudo cargar el tema para editar:\n%s", err.c_str());
    }

    int margin = 16;
    int y = margin;

    titleBox_ = new Fl_Box(margin, y, w() - 2 * margin, 26);
    titleBox_->align(FL_ALIGN_LEFT | FL_ALIGN_INSIDE);
    titleBox_->labelfont(FL_HELVETICA_BOLD);
    y += 32;

    dirtyBox_ = new Fl_Box(margin, y, w() - 2 * margin, 20);
    dirtyBox_->align(FL_ALIGN_LEFT | FL_ALIGN_INSIDE);
    dirtyBox_->labelsize(11);
    dirtyBox_->labelcolor(FL_DARK3);
    y += 30;

    int btnH = 34;

    Fl_Button* generalBtn = new Fl_Button(margin, y, w() - 2 * margin, btnH, "General");
    generalBtn->callback(onOpenGeneral, this);
    y += btnH + 8;

    Fl_Button* terminalBtn = new Fl_Button(margin, y, w() - 2 * margin, btnH, "Terminal");
    terminalBtn->callback(onOpenTerminal, this);
    y += btnH + 8;

    Fl_Button* flwmBtn = new Fl_Button(margin, y, w() - 2 * margin, btnH, "FLWM");
    flwmBtn->callback(onOpenFlwm, this);
    y += btnH + 8;

    Fl_Button* fontsBtn = new Fl_Button(margin, y, w() - 2 * margin, btnH, "Fuentes");
    fontsBtn->callback(onOpenFonts, this);
    y += btnH + 8;

    Fl_Button* advancedBtn = new Fl_Button(margin, y, w() - 2 * margin, btnH, "Avanzado");
    advancedBtn->callback(onOpenAdvanced, this);
    y += btnH + 8;

    Fl_Button* previewBtn = new Fl_Button(margin, y, w() - 2 * margin, btnH, "Vista previa");
    previewBtn->callback(onOpenPreview, this);
    y += btnH + 10;

    // El "Atras" de este menu de nivel superior no tiene a donde volver
    // salvo a la Biblioteca, asi que se comporta igual que "Cancelar":
    // si hay cambios sin guardar, pregunta antes de descartarlos.
    addCategoryNavButtons(this, w(), h(), this, [this]() { cancelAndClose(); });
    end();

    refreshTitle();
}

void EditorWindow::markDirty() {
    dirty_ = true;
    refreshTitle();
}

void EditorWindow::refreshTitle() {
    std::string t = "Editando: " + workingTheme_.name;
    titleBox_->copy_label(t.c_str());
    dirtyBox_->copy_label(dirty_ ? "Cambios sin guardar *" : "Sin cambios pendientes");
    titleBox_->redraw();
    dirtyBox_->redraw();
}

void EditorWindow::closeAllWindows() {
    if (activeCategoryWindow_) {
        Fl_Window* toClose = activeCategoryWindow_;
        activeCategoryWindow_ = nullptr;
        toClose->hide();
        // Fl::delete_widget difiere el borrado hasta que termine el
        // procesamiento de eventos actual: es lo seguro cuando esta
        // funcion se llama desde el propio callback de un boton que vive
        // dentro de esa misma ventana (categoria u ANSI).
        Fl::delete_widget(toClose);
    }
    if (previewWindow_) {
        Fl_Window* toClose = previewWindow_;
        previewWindow_ = nullptr;
        toClose->hide();
        Fl::delete_widget(toClose);
    }
    hide();
}

void EditorWindow::returnFromCategory() {
    if (activeCategoryWindow_) {
        Fl_Window* toClose = activeCategoryWindow_;
        activeCategoryWindow_ = nullptr;
        toClose->hide();
        Fl::delete_widget(toClose);
    }
    refreshTitle();
    show();
}

void EditorWindow::saveAndClose() {
    std::string outPath, err;
    if (!library_.saveTheme(workingTheme_, outPath, err)) {
        fl_alert("No se pudo guardar el tema:\n%s", err.c_str());
        return;  // no cerramos: el usuario no debe perder sus cambios
    }
    dirty_ = false;
    closeAllWindows();
    if (onClosed_) onClosed_();
    Fl::delete_widget(this);
}

void EditorWindow::cancelAndClose() {
    if (dirty_) {
        int choice = fl_choice("Hay cambios sin guardar en este tema.\n¿Descartarlos?",
                                "Seguir editando", "Descartar", nullptr);
        if (choice == 0) return;  // "Seguir editando": no cerramos nada
    }
    closeAllWindows();
    if (onClosed_) onClosed_();
    Fl::delete_widget(this);
}

void EditorWindow::onOpenGeneral(Fl_Widget*, void* userData) {
    auto* editor = static_cast<EditorWindow*>(userData);
    editor->hide();
    auto* win = new GeneralCategoryWindow(editor);
    editor->activeCategoryWindow_ = win;
    win->show();
}

void EditorWindow::onOpenTerminal(Fl_Widget*, void* userData) {
    auto* editor = static_cast<EditorWindow*>(userData);
    editor->hide();
    auto* win = new TerminalCategoryWindow(editor);
    editor->activeCategoryWindow_ = win;
    win->show();
}

void EditorWindow::onOpenFlwm(Fl_Widget*, void* userData) {
    auto* editor = static_cast<EditorWindow*>(userData);
    editor->hide();
    auto* win = new FlwmCategoryWindow(editor);
    editor->activeCategoryWindow_ = win;
    win->show();
}

void EditorWindow::onOpenFonts(Fl_Widget*, void* userData) {
    auto* editor = static_cast<EditorWindow*>(userData);
    editor->hide();
    auto* win = new FontsCategoryWindow(editor);
    editor->activeCategoryWindow_ = win;
    win->show();
}

void EditorWindow::onOpenAdvanced(Fl_Widget*, void* userData) {
    auto* editor = static_cast<EditorWindow*>(userData);
    editor->hide();
    auto* win = new AdvancedCategoryWindow(editor);
    editor->activeCategoryWindow_ = win;
    win->show();
}

void EditorWindow::onOpenPreview(Fl_Widget*, void* userData) {
    auto* editor = static_cast<EditorWindow*>(userData);
    if (editor->previewWindow_) {
        // Ya esta abierta: solo la traemos al frente, no se duplica.
        editor->previewWindow_->show();
        return;
    }
    auto* preview = new PreviewWindow(editor);
    editor->previewWindow_ = preview;
}

}  // namespace fts
