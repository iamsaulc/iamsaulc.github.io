// terminal_category_window.h
// Ventana de categoría "Terminal": fondo, texto, cursor, transparencia,
// scrollbar y configuración básica. Los colores ANSI NO aparecen aquí --
// viven en su propia ventana, accesible mediante el botón
// "Editar colores ANSI".

#ifndef FLWM_THEME_STUDIO_TERMINAL_CATEGORY_WINDOW_H
#define FLWM_THEME_STUDIO_TERMINAL_CATEGORY_WINDOW_H

#include <FL/Fl_Window.H>
#include <FL/Fl_Input.H>

#include "editor_window.h"

namespace fts {

class TerminalCategoryWindow : public Fl_Window {
public:
    explicit TerminalCategoryWindow(EditorWindow* editor);

private:
    EditorWindow* editor_;
    static void onOpenAnsi(Fl_Widget*, void* userData);
};

}  // namespace fts

#endif  // FLWM_THEME_STUDIO_TERMINAL_CATEGORY_WINDOW_H
