// fonts_category_window.h
// Ventana de categoría "Fuentes": familia, tamaño, DPI, antialias e
// hinting. La familia y el tamaño se editan por separado en la interfaz
// aunque internamente se guardan combinados en Fonts.family (p. ej.
// "helvetica-12"), tal como usan los recursos X11 reales.

#ifndef FLWM_THEME_STUDIO_FONTS_CATEGORY_WINDOW_H
#define FLWM_THEME_STUDIO_FONTS_CATEGORY_WINDOW_H

#include <FL/Fl_Window.H>

#include "editor_window.h"

namespace fts {

class FontsCategoryWindow : public Fl_Window {
public:
    explicit FontsCategoryWindow(EditorWindow* editor);
};

}  // namespace fts

#endif  // FLWM_THEME_STUDIO_FONTS_CATEGORY_WINDOW_H
