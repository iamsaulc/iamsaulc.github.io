// theme.cpp
#include "theme.h"

#include <algorithm>
#include <cctype>
#include <fstream>
#include <sstream>

namespace fts {

const std::vector<std::string> kSectionOrder = {
    "Meta", "General", "Terminal", "ANSI", "FLWM", "Fonts", "Advanced"};

namespace {

std::string trim(const std::string& s) {
    size_t start = s.find_first_not_of(" \t\r\n");
    if (start == std::string::npos) return "";
    size_t end = s.find_last_not_of(" \t\r\n");
    return s.substr(start, end - start + 1);
}

}  // namespace

std::string Theme::get(const std::string& section, const std::string& key,
                        const std::string& defaultValue) const {
    auto secIt = sections.find(section);
    if (secIt == sections.end()) return defaultValue;
    auto keyIt = secIt->second.find(key);
    if (keyIt == secIt->second.end()) return defaultValue;
    return keyIt->second;
}

void Theme::set(const std::string& section, const std::string& key,
                 const std::string& value) {
    sections[section][key] = value;
}

bool Theme::hasKey(const std::string& section, const std::string& key) const {
    auto secIt = sections.find(section);
    if (secIt == sections.end()) return false;
    return secIt->second.count(key) > 0;
}

bool loadThemeFile(const std::string& path, Theme& outTheme,
                    std::string& errorMessage) {
    std::ifstream in(path.c_str());
    if (!in.is_open()) {
        errorMessage = "No se pudo abrir el archivo: " + path;
        return false;
    }

    Theme theme;
    std::string currentSection;
    std::string line;
    int lineNumber = 0;

    while (std::getline(in, line)) {
        lineNumber++;
        std::string trimmed = trim(line);

        if (trimmed.empty() || trimmed[0] == ';' || trimmed[0] == '#') {
            continue;  // línea vacía o comentario
        }

        if (trimmed.front() == '[' && trimmed.back() == ']') {
            currentSection = trimmed.substr(1, trimmed.size() - 2);
            continue;
        }

        size_t eq = trimmed.find('=');
        if (eq == std::string::npos) {
            // Línea sin '=' fuera de una sección reconocible: la ignoramos
            // en vez de fallar. Preferimos un tema incompleto a un error
            // bloqueante para el usuario.
            continue;
        }

        std::string key = trim(trimmed.substr(0, eq));
        std::string value = trim(trimmed.substr(eq + 1));

        if (currentSection == "Meta") {
            if (key == "name") theme.name = value;
            else if (key == "description") theme.description = value;
            else if (key == "version") {
                try { theme.version = std::stoi(value); } catch (...) {}
            }
        } else if (!currentSection.empty()) {
            theme.sections[currentSection][key] = value;
        }
    }

    if (theme.name.empty()) {
        errorMessage = "El archivo de tema no tiene nombre en [Meta]: " + path;
        return false;
    }

    outTheme = theme;
    return true;
}

bool saveThemeFile(const std::string& path, const Theme& theme,
                    std::string& errorMessage) {
    std::ofstream out(path.c_str(), std::ios::trunc);
    if (!out.is_open()) {
        errorMessage = "No se pudo escribir el archivo: " + path;
        return false;
    }

    out << "[Meta]\n";
    out << "name=" << theme.name << "\n";
    out << "description=" << theme.description << "\n";
    out << "version=" << theme.version << "\n";
    out << "\n";

    for (const auto& sectionName : kSectionOrder) {
        if (sectionName == "Meta") continue;
        auto it = theme.sections.find(sectionName);
        if (it == theme.sections.end() || it->second.empty()) continue;

        out << "[" << sectionName << "]\n";
        for (const auto& kv : it->second) {
            out << kv.first << "=" << kv.second << "\n";
        }
        out << "\n";
    }

    return true;
}

}  // namespace fts
