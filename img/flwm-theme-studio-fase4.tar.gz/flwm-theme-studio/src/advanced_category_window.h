// advanced_category_window.h
// Editor de texto libre para la sección "Advanced": cualquier recurso X11
// que el importador no supo clasificar en una categoría conocida, más
// cualquier línea que el usuario avanzado quiera añadir a mano. Formato
// mostrado: una línea por recurso, "clave=valor" (igual que el resto del
// archivo .theme interno).
//
// Igual que los recuadros de color en las demás categorías, cada cambio
// de texto se escribe de inmediato en el Theme en memoria (nunca en
// disco) -- así "Guardar"/"Cancelar"/"Atrás" funcionan exactamente igual
// que en el resto de ventanas, sin lógica especial.

#ifndef FLWM_THEME_STUDIO_ADVANCED_CATEGORY_WINDOW_H
#define FLWM_THEME_STUDIO_ADVANCED_CATEGORY_WINDOW_H

#include <FL/Fl_Window.H>
#include <FL/Fl_Text_Buffer.H>
#include <FL/Fl_Text_Editor.H>

#include "editor_window.h"

namespace fts {

class AdvancedCategoryWindow : public Fl_Window {
public:
    explicit AdvancedCategoryWindow(EditorWindow* editor);

private:
    Fl_Text_Buffer* buffer_;
};

}  // namespace fts

#endif  // FLWM_THEME_STUDIO_ADVANCED_CATEGORY_WINDOW_H
