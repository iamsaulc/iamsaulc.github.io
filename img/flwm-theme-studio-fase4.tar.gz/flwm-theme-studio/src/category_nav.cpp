// category_nav.cpp
#include "category_nav.h"

#include <FL/Fl_Button.H>
#include <FL/Fl_Group.H>

#include "editor_window.h"

namespace fts {

namespace {

void onBackClicked(Fl_Widget*, void* userData) {
    auto* fn = static_cast<std::function<void()>*>(userData);
    (*fn)();
}

void onSaveClicked(Fl_Widget*, void* userData) {
    static_cast<EditorWindow*>(userData)->saveAndClose();
}

void onCancelClicked(Fl_Widget*, void* userData) {
    static_cast<EditorWindow*>(userData)->cancelAndClose();
}

}  // namespace

void addCategoryNavButtons(Fl_Group* parent, int winW, int winH,
                            EditorWindow* editor, std::function<void()> onBack) {
    Fl_Group* savedGroup = Fl_Group::current();
    parent->begin();

    int margin = 12;
    int btnH = 30;
    int y = winH - btnH - margin;
    int btnW = 110;

    // Nota: este puntero se filtra deliberadamente (vive lo que vive la
    // ventana, que en esta fase nunca se destruye explícitamente). Fl no
    // permite pasar un std::function directamente como callback en C, así
    // que se aloja en el heap y el botón guarda solo el puntero.
    auto* onBackHeap = new std::function<void()>(std::move(onBack));

    Fl_Button* back = new Fl_Button(margin, y, btnW, btnH, "@< Atras");
    back->callback(onBackClicked, onBackHeap);

    Fl_Button* cancel = new Fl_Button(winW - margin - btnW, y, btnW, btnH, "Cancelar");
    cancel->callback(onCancelClicked, editor);

    Fl_Button* save = new Fl_Button(winW - margin - btnW * 2 - 10, y, btnW, btnH, "Guardar");
    save->callback(onSaveClicked, editor);

    if (savedGroup) savedGroup->begin();
}

}  // namespace fts
