// xdefaults.h
// Traductor entre el formato interno Theme y el archivo .Xdefaults real que
// entiende X11/Aterm/FLTK/flwm. Es el único lugar del programa que conoce
// los nombres de recursos X11 concretos.
//
// Import: cualquier recurso reconocido en kMapping va a su
// sección/clave canónica. Cualquier recurso NO reconocido se guarda tal
// cual en la sección "Advanced" (clave = recurso X11 original), así nunca
// se pierde información al importar un .Xdefaults ajeno.
//
// Export: se recorre kMapping y se escribe cada recurso conocido a partir
// del Theme; luego se vuelcan las líneas crudas de "Advanced" tal cual.

#ifndef FLWM_THEME_STUDIO_XDEFAULTS_H
#define FLWM_THEME_STUDIO_XDEFAULTS_H

#include <string>
#include <vector>

#include "theme.h"

namespace fts {

struct ResourceMapping {
    std::string resource;   // p. ej. "Aterm*background"
    std::string section;    // p. ej. "Terminal"
    std::string key;        // p. ej. "background"
    // Si no está vacío, este recurso adicional se escribe siempre con el
    // mismo valor al exportar (p. ej. *selectColor y *selection_color son
    // el mismo concepto con dos nombres distintos en la práctica).
    std::string exportSynonym;
};

// Tabla de recursos "conocidos" -> sección/clave canónica del Theme.
const std::vector<ResourceMapping>& resourceMappingTable();

// Convierte el contenido completo de un .Xdefaults (ya leído en memoria)
// en un Theme. themeName se usa para rellenar [Meta] name, ya que un
// .Xdefaults importado no trae ese dato.
Theme xdefaultsToTheme(const std::string& xdefaultsContent,
                        const std::string& themeName);

// Genera el contenido completo de un .Xdefaults a partir de un Theme,
// listo para escribir en ~/.Xdefaults.
std::string themeToXdefaults(const Theme& theme);

}  // namespace fts

#endif  // FLWM_THEME_STUDIO_XDEFAULTS_H
