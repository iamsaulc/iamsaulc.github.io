// xdefaults.cpp
#include "xdefaults.h"

#include <map>
#include <sstream>

namespace fts {

namespace {

std::string trim(const std::string& s) {
    size_t start = s.find_first_not_of(" \t\r\n");
    if (start == std::string::npos) return "";
    size_t end = s.find_last_not_of(" \t\r\n");
    return s.substr(start, end - start + 1);
}

}  // namespace

const std::vector<ResourceMapping>& resourceMappingTable() {
    static const std::vector<ResourceMapping> table = {
        // --- General ---
        {"*background", "General", "background", ""},
        {"*foreground", "General", "foreground", ""},
        {"*labelcolor", "General", "labelcolor", ""},
        {"*selectColor", "General", "selectColor", "*selection_color"},
        {"*background2", "General", "background2", "*bg2"},

        // --- Terminal (Aterm*) ---
        {"Aterm*scrollBar", "Terminal", "scrollBar", ""},
        {"Aterm*transparent", "Terminal", "transparent", ""},
        {"Aterm*shading", "Terminal", "shading", ""},
        {"Aterm*title", "Terminal", "title", ""},
        {"Aterm*font", "Terminal", "font", ""},
        {"Aterm*saveLines", "Terminal", "saveLines", ""},
        {"Aterm*background", "Terminal", "background", ""},
        {"Aterm*foreground", "Terminal", "foreground", ""},
        {"Aterm*cursorColor", "Terminal", "cursorColor", ""},
        {"Aterm*pointerColor", "Terminal", "pointerColor", ""},

        // --- ANSI (Aterm*color0..15) ---
        {"Aterm*color0", "ANSI", "color0", ""},
        {"Aterm*color1", "ANSI", "color1", ""},
        {"Aterm*color2", "ANSI", "color2", ""},
        {"Aterm*color3", "ANSI", "color3", ""},
        {"Aterm*color4", "ANSI", "color4", ""},
        {"Aterm*color5", "ANSI", "color5", ""},
        {"Aterm*color6", "ANSI", "color6", ""},
        {"Aterm*color7", "ANSI", "color7", ""},
        {"Aterm*color8", "ANSI", "color8", ""},
        {"Aterm*color9", "ANSI", "color9", ""},
        {"Aterm*color10", "ANSI", "color10", ""},
        {"Aterm*color11", "ANSI", "color11", ""},
        {"Aterm*color12", "ANSI", "color12", ""},
        {"Aterm*color13", "ANSI", "color13", ""},
        {"Aterm*color14", "ANSI", "color14", ""},
        {"Aterm*color15", "ANSI", "color15", ""},

        // --- FLWM ---
        {"flwm*background", "FLWM", "background", ""},
        {"flwm*foreground", "FLWM", "foreground", ""},
        {"flwm*activeBackground", "FLWM", "activeBackground", ""},
        {"flwm*activeForeground", "FLWM", "activeForeground", ""},

        // --- Fonts ---
        {"*font", "Fonts", "family", ""},
        {"Xft.dpi", "Fonts", "dpi", ""},
        {"Xft.antialias", "Fonts", "antialias", ""},
        {"Xft.hinting", "Fonts", "hinting", ""},
    };
    return table;
}

Theme xdefaultsToTheme(const std::string& xdefaultsContent,
                        const std::string& themeName) {
    Theme theme;
    theme.name = themeName;
    theme.version = 1;

    // Índice recurso -> mapping, para lookup O(log n) al importar.
    std::map<std::string, ResourceMapping> byResource;
    for (const auto& m : resourceMappingTable()) {
        byResource[m.resource] = m;
    }

    std::istringstream in(xdefaultsContent);
    std::string line;
    while (std::getline(in, line)) {
        std::string trimmed = trim(line);
        if (trimmed.empty() || trimmed[0] == '!') continue;

        size_t colon = trimmed.find(':');
        if (colon == std::string::npos) continue;

        std::string resource = trim(trimmed.substr(0, colon));
        std::string value = trim(trimmed.substr(colon + 1));

        auto it = byResource.find(resource);
        if (it != byResource.end()) {
            theme.set(it->second.section, it->second.key, value);
        } else {
            // Recurso desconocido: se preserva íntegro en Advanced para no
            // perder nada al importar un tema ajeno.
            theme.set("Advanced", resource, value);
        }
    }

    return theme;
}

std::string themeToXdefaults(const Theme& theme) {
    std::ostringstream out;

    out << "! Generado por FLWM Theme Studio -- tema: " << theme.name << "\n";
    out << "! No editar a mano; los cambios se perderan al reaplicar.\n\n";

    for (const auto& m : resourceMappingTable()) {
        if (!theme.hasKey(m.section, m.key)) continue;
        const std::string& value = theme.get(m.section, m.key);
        out << m.resource << ":\t" << value << "\n";
        if (!m.exportSynonym.empty()) {
            out << m.exportSynonym << ":\t" << value << "\n";
        }
    }

    auto advIt = theme.sections.find("Advanced");
    if (advIt != theme.sections.end() && !advIt->second.empty()) {
        out << "\n! --- Lineas avanzadas / no categorizadas ---\n";
        for (const auto& kv : advIt->second) {
            out << kv.first << ":\t" << kv.second << "\n";
        }
    }

    return out.str();
}

}  // namespace fts
