// theme_diff.h
// Calcula las diferencias entre dos temas, sección por sección y clave por
// clave. Pura lógica, sin FLTK, para poder probarla de forma aislada.

#ifndef FLWM_THEME_STUDIO_THEME_DIFF_H
#define FLWM_THEME_STUDIO_THEME_DIFF_H

#include <string>
#include <vector>

#include "theme.h"

namespace fts {

struct DiffEntry {
    std::string section;
    std::string key;
    std::string valueA;  // vacio si la clave no existe en el tema A
    std::string valueB;  // vacio si la clave no existe en el tema B
};

// Devuelve solo las claves cuyo valor difiere (o que existen en un tema y
// no en el otro). Si valueA/valueB están vacíos, se debe mostrar como
// "(no definido)" en la interfaz, no como cadena vacía real.
std::vector<DiffEntry> computeThemeDiff(const Theme& a, const Theme& b);

}  // namespace fts

#endif  // FLWM_THEME_STUDIO_THEME_DIFF_H
